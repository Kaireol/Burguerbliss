# BurgerBliss - Website com Análise de Feedback por IA

Este projeto consiste em um website para uma hamburgueria fictícia chamada BurgerBliss, que inclui um sistema de avaliações de clientes e um agente de IA para análise de feedback.

## Visão Geral

O projeto é dividido em duas partes principais:

1. **Website da Hamburgueria**: Um site completo para a hamburgueria fictícia BurgerBliss, com páginas de início, menu, sobre, contato e avaliações.

2. **Agente de IA para Análise de Feedback**: Um sistema de IA que analisa as avaliações dos clientes, identifica sentimentos, extrai tópicos mencionados e gera resumos e visualizações dos dados.

## Estrutura do Projeto

```
burgerbliss/
├── public/               # Arquivos públicos (imagens, etc.)
├── src/
│   ├── ai/              # Módulos do agente de IA
│   │   ├── index.js     # Ponto de entrada do agente de IA
│   │   ├── sentimentAnalysis.js  # Análise de sentimento
│   │   ├── reviewSummary.js      # Resumo de avaliações
│   │   ├── visualizations.js     # Geração de visualizações
│   │   └── test.js      # Testes do agente de IA
│   ├── assets/          # Recursos estáticos (logo, etc.)
│   ├── components/      # Componentes React reutilizáveis
│   │   ├── AIAnalysis/  # Componentes de análise de IA
│   │   ├── Footer/      # Componente de rodapé
│   │   ├── Header/      # Componente de cabeçalho
│   │   ├── ProductCard/ # Componente de card de produto
│   │   ├── ReviewCard/  # Componente de card de avaliação
│   │   ├── ReviewFilter/ # Componente de filtro de avaliações
│   │   └── ui/          # Componentes de UI básicos
│   ├── data/            # Dados fictícios
│   │   ├── products.js  # Dados de produtos
│   │   └── reviews.js   # Dados de avaliações
│   ├── hooks/           # Hooks personalizados
│   ├── lib/             # Bibliotecas e utilitários
│   ├── pages/           # Páginas do website
│   │   ├── About/       # Página Sobre
│   │   ├── Contact/     # Página de Contato
│   │   ├── Home/        # Página Inicial
│   │   ├── Menu/        # Página de Menu
│   │   └── Reviews/     # Página de Avaliações
│   ├── utils/           # Utilitários
│   │   └── avatarGenerator.js # Gerador de avatares
│   ├── App.css          # Estilos da aplicação
│   ├── App.jsx          # Componente principal
│   ├── index.css        # Estilos globais
│   └── main.jsx         # Ponto de entrada da aplicação
├── test-ai-agent.js     # Script para testar o agente de IA
├── package.json         # Dependências e scripts
└── README.md            # Esta documentação
```

## Tecnologias Utilizadas

- **Frontend**: React, React Router, Tailwind CSS, shadcn/ui
- **Visualizações**: Recharts
- **Ícones**: Lucide React
- **Bundler**: Vite

## Funcionalidades

### Website da Hamburgueria

- **Página Inicial**: Apresentação da hamburgueria, destaques do menu e avaliações recentes.
- **Menu**: Exibição de todos os produtos, com filtros por categoria e pesquisa.
- **Sobre**: Informações sobre a história, valores e equipe da hamburgueria.
- **Contato**: Formulário de contato, informações de localização e horário de funcionamento.
- **Avaliações**: Sistema completo de avaliações de clientes, com filtros e análise de IA.

### Agente de IA para Análise de Feedback

- **Análise de Sentimento**: Identifica se as avaliações são positivas, neutras ou negativas.
- **Extração de Tópicos**: Identifica os principais tópicos mencionados nas avaliações (sabor, atendimento, preço, etc.).
- **Resumo de Avaliações**: Gera um resumo textual das avaliações, destacando pontos positivos e negativos.
- **Visualizações**: Gera gráficos e visualizações dos dados de avaliações.

## Como Executar o Projeto

### Requisitos

- Node.js (versão 18 ou superior)
- npm, yarn ou pnpm

### Instalação

1. Clone o repositório:
   ```
   git clone <url-do-repositorio>
   cd burgerbliss
   ```

2. Instale as dependências:
   ```
   npm install
   # ou
   yarn install
   # ou
   pnpm install
   ```

3. Inicie o servidor de desenvolvimento:
   ```
   npm run dev
   # ou
   yarn dev
   # ou
   pnpm dev
   ```

4. Acesse o website em `http://localhost:5173`

### Testes do Agente de IA

Para testar o agente de IA separadamente:

```
npm run test:ai
# ou
yarn test:ai
# ou
pnpm test:ai
```

## Personalização

### Produtos e Avaliações

Os produtos e avaliações fictícios estão definidos nos arquivos:
- `src/data/products.js`
- `src/data/reviews.js`

Você pode modificar esses arquivos para adicionar, remover ou alterar produtos e avaliações.

### Cores e Estilos

As cores e estilos principais estão definidos em:
- `src/index.css` (variáveis CSS)

## Agente de IA para Análise de Feedback

### Módulos

- **sentimentAnalysis.js**: Contém funções para analisar o sentimento de avaliações com base em palavras-chave e pontuação.
- **reviewSummary.js**: Contém funções para extrair tópicos e gerar resumos das avaliações.
- **visualizations.js**: Contém funções para gerar dados formatados para visualizações.
- **index.js**: Integra todos os módulos e fornece uma API unificada.

### Como Usar o Agente de IA

```javascript
import { analyzeReviews, generateReviewReport } from './src/ai';

// Analisar avaliações
const analysisResults = analyzeReviews(reviews);

// Gerar relatório completo
const report = generateReviewReport(reviews);
```

## Considerações Finais

Este projeto foi desenvolvido como um estudo sobre IA para análise de feedback de clientes. O website da hamburgueria serve como um ambiente de teste para o agente de IA, permitindo visualizar como a análise de sentimento e o resumo de avaliações podem ser aplicados em um cenário real.

O agente de IA utiliza uma abordagem baseada em dicionário de palavras-chave para análise de sentimento, o que é uma técnica simples mas eficaz para demonstração. Em um ambiente de produção, seria recomendável utilizar modelos de aprendizado de máquina mais avançados para maior precisão.

