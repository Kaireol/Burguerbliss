# Instruções de Uso - BurgerBliss

Este documento fornece instruções para executar e utilizar o website da hamburgueria BurgerBliss e o agente de IA para análise de feedback.

## Requisitos

- Node.js (versão 18 ou superior)
- npm, yarn ou pnpm

## Instalação

1. Descompacte o arquivo do projeto em uma pasta de sua preferência.

2. Abra um terminal e navegue até a pasta do projeto:
   ```
   cd caminho/para/burgerbliss
   ```

3. Instale as dependências:
   ```
   npm install
   # ou
   yarn install
   # ou
   pnpm install
   ```

## Execução

### Modo de Desenvolvimento

Para executar o projeto em modo de desenvolvimento:

```
npm run dev
# ou
yarn dev
# ou
pnpm dev
```

Isso iniciará o servidor de desenvolvimento e abrirá o website em `http://localhost:5173`.

### Compilação para Produção

Para compilar o projeto para produção:

```
npm run build
# ou
yarn build
# ou
pnpm build
```

Os arquivos compilados serão gerados na pasta `dist`.

### Visualização da Versão de Produção

Para visualizar a versão compilada:

```
npm run preview
# ou
yarn preview
# ou
pnpm preview
```

## Teste do Agente de IA

Para testar o agente de IA separadamente:

```
npm run test:ai
# ou
yarn test:ai
# ou
pnpm test:ai
```

## Estrutura do Website

O website da hamburgueria BurgerBliss possui as seguintes páginas:

1. **Página Inicial**: Apresentação da hamburgueria, destaques do menu e avaliações recentes.
   - URL: `/`

2. **Menu**: Exibição de todos os produtos, com filtros por categoria e pesquisa.
   - URL: `/menu`

3. **Sobre**: Informações sobre a história, valores e equipe da hamburgueria.
   - URL: `/about`

4. **Contato**: Formulário de contato, informações de localização e horário de funcionamento.
   - URL: `/contact`

5. **Avaliações**: Sistema completo de avaliações de clientes, com filtros e análise de IA.
   - URL: `/reviews`

## Uso do Agente de IA

O agente de IA para análise de feedback está integrado à página de avaliações. Para utilizá-lo:

1. Acesse a página de avaliações (`/reviews`).
2. Clique no botão "Mostrar Análise de IA".
3. O agente de IA analisará automaticamente as avaliações e exibirá os resultados.
4. Para atualizar a análise, clique no botão "Atualizar Análise".

## Personalização

### Produtos e Avaliações

Os produtos e avaliações fictícios estão definidos nos arquivos:
- `src/data/products.js`
- `src/data/reviews.js`

Você pode modificar esses arquivos para adicionar, remover ou alterar produtos e avaliações.

### Cores e Estilos

As cores e estilos principais estão definidos em:
- `src/index.css` (variáveis CSS)

## Documentação Adicional

Para informações mais detalhadas sobre o projeto, consulte os seguintes documentos:

- `README.md`: Visão geral do projeto.
- `AI_AGENT_GUIDE.md`: Guia detalhado sobre o agente de IA.

## Suporte

Em caso de dúvidas ou problemas, entre em contato através do email: suporte@burgerbliss.com

