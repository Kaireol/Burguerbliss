import { useState } from 'react';
import { Star, SlidersHorizontal, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ReviewFilter = ({ onFilterChange, products }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedRating, setSelectedRating] = useState(0);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [sortBy, setSortBy] = useState('recent');
  
  const toggleFilter = () => {
    setIsOpen(!isOpen);
  };
  
  const handleRatingChange = (rating) => {
    const newRating = selectedRating === rating ? 0 : rating;
    setSelectedRating(newRating);
    applyFilters(newRating, selectedProduct, sortBy);
  };
  
  const handleProductChange = (e) => {
    const product = e.target.value;
    setSelectedProduct(product);
    applyFilters(selectedRating, product, sortBy);
  };
  
  const handleSortChange = (e) => {
    const sort = e.target.value;
    setSortBy(sort);
    applyFilters(selectedRating, selectedProduct, sort);
  };
  
  const applyFilters = (rating, product, sort) => {
    onFilterChange({
      rating,
      product,
      sortBy: sort
    });
  };
  
  const resetFilters = () => {
    setSelectedRating(0);
    setSelectedProduct('');
    setSortBy('recent');
    onFilterChange({
      rating: 0,
      product: '',
      sortBy: 'recent'
    });
  };
  
  // Renderiza as estrelas para seleção
  const renderRatingOptions = () => {
    const ratings = [5, 4, 3, 2, 1];
    
    return (
      <div className="flex flex-col gap-2">
        <p className="text-sm font-medium">Filtrar por avaliação:</p>
        <div className="flex gap-2">
          {ratings.map((rating) => (
            <button
              key={rating}
              onClick={() => handleRatingChange(rating)}
              className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm ${
                selectedRating === rating 
                  ? 'bg-secondary text-secondary-foreground' 
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              <span>{rating}</span>
              <Star className="h-3 w-3" fill={selectedRating === rating ? 'currentColor' : 'none'} />
            </button>
          ))}
        </div>
      </div>
    );
  };
  
  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold">Avaliações dos Clientes</h3>
        <Button
          variant="outline"
          size="sm"
          onClick={toggleFilter}
          className="flex items-center gap-1"
        >
          <SlidersHorizontal className="h-4 w-4" />
          <span>Filtros</span>
          {isOpen ? (
            <ChevronUp className="h-4 w-4" />
          ) : (
            <ChevronDown className="h-4 w-4" />
          )}
        </Button>
      </div>
      
      {isOpen && (
        <div className="bg-muted/30 rounded-lg p-4 mb-4 space-y-4">
          {/* Filtro por avaliação (estrelas) */}
          {renderRatingOptions()}
          
          {/* Filtro por produto */}
          <div>
            <p className="text-sm font-medium mb-2">Filtrar por produto:</p>
            <select
              value={selectedProduct}
              onChange={handleProductChange}
              className="w-full p-2 border rounded-md bg-background"
            >
              <option value="">Todos os produtos</option>
              {products.map((product) => (
                <option key={product.id} value={product.id}>
                  {product.name}
                </option>
              ))}
            </select>
          </div>
          
          {/* Ordenação */}
          <div>
            <p className="text-sm font-medium mb-2">Ordenar por:</p>
            <select
              value={sortBy}
              onChange={handleSortChange}
              className="w-full p-2 border rounded-md bg-background"
            >
              <option value="recent">Mais recentes</option>
              <option value="oldest">Mais antigos</option>
              <option value="highest">Maior avaliação</option>
              <option value="lowest">Menor avaliação</option>
            </select>
          </div>
          
          {/* Botão para resetar filtros */}
          <div className="flex justify-end">
            <Button
              variant="ghost"
              size="sm"
              onClick={resetFilters}
            >
              Limpar filtros
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReviewFilter;

