import { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { RefreshCw, ThumbsUp, ThumbsDown, Smile, Meh, Frown, TrendingUp, MessageSquare, BarChart2 } from 'lucide-react';

const AIAnalysis = ({ reviews, isAnalyzing, analysisData, onAnalyze }) => {
  const [activeTab, setActiveTab] = useState("sentiment");
  
  // Usar dados da análise ou valores padrão
  const sentimentData = analysisData?.sentimentData || [
    { name: 'Positivo', value: 65, color: '#2B9348' },
    { name: 'Neutro', value: 25, color: '#FFB627' },
    { name: 'Negativo', value: 10, color: '#D62300' },
  ];
  
  const ratingDistribution = analysisData?.ratingDistribution || [
    { name: '5 estrelas', count: 42, color: '#2B9348' },
    { name: '4 estrelas', count: 23, color: '#65B75E' },
    { name: '3 estrelas', count: 15, color: '#FFB627' },
    { name: '2 estrelas', count: 8, color: '#FF8A5B' },
    { name: '1 estrela', count: 2, color: '#D62300' },
  ];
  
  const topTopics = analysisData?.topTopics || [
    { topic: 'Sabor', count: 45, sentiment: 'positive' },
    { topic: 'Atendimento', count: 32, sentiment: 'positive' },
    { topic: 'Preço', count: 28, sentiment: 'neutral' },
    { topic: 'Ambiente', count: 25, sentiment: 'positive' },
    { topic: 'Tempo de espera', count: 18, sentiment: 'negative' },
  ];
  
  const summary = analysisData?.summary || "A maioria dos clientes está satisfeita com os produtos da BurgerBliss, destacando principalmente o sabor dos hambúrgueres e a qualidade do atendimento. Pontos de melhoria incluem o tempo de espera e alguns comentários sobre preços. Recomenda-se focar em otimizar o tempo de preparo dos pedidos para melhorar ainda mais a experiência do cliente.";
  
  const positiveTopics = analysisData?.positiveTopics || ['Sabor', 'Qualidade do atendimento', 'Ambiente agradável'];
  const neutralTopics = analysisData?.neutralTopics || ['Preços praticados', 'Variedade do cardápio', 'Localização'];
  const negativeTopics = analysisData?.negativeTopics || ['Tempo de espera', 'Opções vegetarianas', 'Estacionamento'];
  
  const handleAnalyzeClick = () => {
    if (onAnalyze) {
      onAnalyze();
    }
  };
  
  const getSentimentIcon = (sentiment) => {
    switch (sentiment) {
      case 'positive':
        return <ThumbsUp className="h-4 w-4 text-accent" />;
      case 'negative':
        return <ThumbsDown className="h-4 w-4 text-destructive" />;
      default:
        return <Meh className="h-4 w-4 text-secondary" />;
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">Análise de Avaliações</h2>
          <p className="text-muted-foreground">
            Análise de sentimento e resumo das {reviews.length} avaliações de clientes
          </p>
        </div>
        <Button 
          onClick={handleAnalyzeClick} 
          disabled={isAnalyzing}
          className="bg-primary text-white hover:bg-primary/90"
        >
          {isAnalyzing ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Analisando...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4 mr-2" />
              Atualizar Análise
            </>
          )}
        </Button>
      </div>
      
      <Tabs defaultValue="sentiment" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="sentiment" className="flex items-center gap-2">
            <Smile className="h-4 w-4" />
            <span className="hidden sm:inline">Sentimento</span>
          </TabsTrigger>
          <TabsTrigger value="topics" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            <span className="hidden sm:inline">Tópicos</span>
          </TabsTrigger>
          <TabsTrigger value="summary" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            <span className="hidden sm:inline">Resumo</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="sentiment" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Gráfico de pizza para sentimento */}
            <Card>
              <CardHeader>
                <CardTitle>Distribuição de Sentimento</CardTitle>
                <CardDescription>
                  Análise geral do sentimento das avaliações
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={sentimentData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {sentimentData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Gráfico de barras para distribuição de avaliações */}
            <Card>
              <CardHeader>
                <CardTitle>Distribuição de Avaliações</CardTitle>
                <CardDescription>
                  Contagem de avaliações por número de estrelas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={ratingDistribution}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count">
                        {ratingDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="topics" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tópicos Mais Mencionados</CardTitle>
              <CardDescription>
                Principais assuntos comentados nas avaliações
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topTopics.map((topic, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getSentimentIcon(topic.sentiment)}
                      <span className="font-medium">{topic.topic}</span>
                    </div>
                    <div className="flex items-center">
                      <div className="w-48 bg-muted rounded-full h-2.5 mr-2">
                        <div 
                          className={`h-2.5 rounded-full ${
                            topic.sentiment === 'positive' ? 'bg-accent' : 
                            topic.sentiment === 'negative' ? 'bg-destructive' : 'bg-secondary'
                          }`}
                          style={{ width: `${(topic.count / 50) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-muted-foreground">{topic.count} menções</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="summary" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Resumo da Análise</CardTitle>
              <CardDescription>
                Insights gerados a partir das avaliações dos clientes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-foreground">
                A maioria dos clientes está satisfeita com os produtos da BurgerBliss, destacando principalmente o sabor dos hambúrgueres e a qualidade do atendimento. Pontos de melhoria incluem o tempo de espera e alguns comentários sobre preços. Recomenda-se focar em otimizar o tempo de preparo dos pedidos para melhorar ainda mais a experiência do cliente.
              </p>
              
              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-background border rounded-lg p-4 flex flex-col items-center">
                  <div className="bg-accent/20 p-2 rounded-full mb-2">
                    <ThumbsUp className="h-6 w-6 text-accent" />
                  </div>
                  <h4 className="font-bold text-center">Pontos Positivos</h4>
                  <ul className="mt-2 text-sm space-y-1">
                    <li>• Sabor dos hambúrgueres</li>
                    <li>• Qualidade do atendimento</li>
                    <li>• Ambiente agradável</li>
                  </ul>
                </div>
                
                <div className="bg-background border rounded-lg p-4 flex flex-col items-center">
                  <div className="bg-secondary/20 p-2 rounded-full mb-2">
                    <Meh className="h-6 w-6 text-secondary" />
                  </div>
                  <h4 className="font-bold text-center">Pontos Neutros</h4>
                  <ul className="mt-2 text-sm space-y-1">
                    <li>• Preços praticados</li>
                    <li>• Variedade do cardápio</li>
                    <li>• Localização</li>
                  </ul>
                </div>
                
                <div className="bg-background border rounded-lg p-4 flex flex-col items-center">
                  <div className="bg-destructive/20 p-2 rounded-full mb-2">
                    <ThumbsDown className="h-6 w-6 text-destructive" />
                  </div>
                  <h4 className="font-bold text-center">Pontos a Melhorar</h4>
                  <ul className="mt-2 text-sm space-y-1">
                    <li>• Tempo de espera</li>
                    <li>• Opções vegetarianas</li>
                    <li>• Estacionamento</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AIAnalysis;

