import { useState, useEffect } from 'react';
import AIAnalysis from './AIAnalysis';
import { analyzeReviews, generateReviewReport } from '@/ai';

/**
 * Componente de integração entre o componente visual AIAnalysis e o módulo de IA
 * 
 * Este componente processa as avaliações usando o módulo de IA e fornece
 * os dados formatados para o componente visual AIAnalysis.
 */
const AIAnalysisIntegration = ({ reviews }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisData, setAnalysisData] = useState(null);
  
  // Realizar análise inicial ao carregar o componente
  useEffect(() => {
    if (reviews && reviews.length > 0 && !analysisData) {
      handleAnalyze();
    }
  }, [reviews]);
  
  // Função para analisar as avaliações
  const handleAnalyze = () => {
    setIsAnalyzing(true);
    
    // Simular um pequeno atraso para dar a impressão de processamento
    setTimeout(() => {
      try {
        // Gerar relatório completo
        const report = generateReviewReport(reviews);
        
        if (report.success) {
          // Formatar dados para visualização
          const formattedData = {
            sentimentData: report.data.visualizations.sentimentPieData,
            ratingDistribution: report.data.visualizations.ratingBarData,
            topTopics: report.data.visualizations.topicsData,
            summary: report.data.visualizations.summary,
            positiveTopics: report.data.visualizations.positiveTopics,
            neutralTopics: report.data.visualizations.neutralTopics,
            negativeTopics: report.data.visualizations.negativeTopics,
            statistics: report.data.statistics
          };
          
          setAnalysisData(formattedData);
        } else {
          console.error("Erro na análise:", report.message);
        }
      } catch (error) {
        console.error("Erro ao processar análise:", error);
      } finally {
        setIsAnalyzing(false);
      }
    }, 1000);
  };
  
  return (
    <AIAnalysis 
      reviews={reviews}
      isAnalyzing={isAnalyzing}
      analysisData={analysisData}
      onAnalyze={handleAnalyze}
    />
  );
};

export default AIAnalysisIntegration;

