import { Star } from 'lucide-react';

const ReviewCard = ({ review }) => {
  const { id, customerName, customerImage, date, rating, comment, productName } = review;
  
  // Função para formatar a data
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('pt-BR', options);
  };
  
  // Função para renderizar as estrelas
  const renderStars = (rating) => {
    const stars = [];
    
    for (let i = 1; i <= 5; i++) {
      if (i <= rating) {
        // Estrela preenchida
        stars.push(
          <Star key={i} className="h-4 w-4 text-secondary fill-secondary" />
        );
      } else {
        // Estrela vazia
        stars.push(
          <Star key={i} className="h-4 w-4 text-muted-foreground" />
        );
      }
    }
    
    return stars;
  };
  
  return (
    <div className="card hover:shadow-md transition-shadow duration-300">
      <div className="flex items-start gap-4">
        {/* Avatar do cliente */}
        <div className="flex-shrink-0">
          <img 
            src={customerImage} 
            alt={customerName} 
            className="w-12 h-12 rounded-full object-cover border-2 border-secondary"
          />
        </div>
        
        {/* Conteúdo da avaliação */}
        <div className="flex-grow">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
            <h4 className="font-bold">{customerName}</h4>
            <span className="text-xs text-muted-foreground">{formatDate(date)}</span>
          </div>
          
          <div className="flex items-center mb-2">
            <div className="flex mr-2">
              {renderStars(rating)}
            </div>
            <span className="text-sm text-muted-foreground">
              Avaliou: <span className="font-medium text-foreground">{productName}</span>
            </span>
          </div>
          
          <p className="text-sm text-foreground">{comment}</p>
        </div>
      </div>
    </div>
  );
};

export default ReviewCard;

