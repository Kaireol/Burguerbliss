import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import logo from '../../assets/logo.svg';
import { Button } from '@/components/ui/button';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <img src={logo} alt="BurgerBliss Logo" className="h-12" />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link to="/" className="text-foreground hover:text-primary font-medium">
            Início
          </Link>
          <Link to="/menu" className="text-foreground hover:text-primary font-medium">
            Menu
          </Link>
          <Link to="/about" className="text-foreground hover:text-primary font-medium">
            Sobre
          </Link>
          <Link to="/reviews" className="text-foreground hover:text-primary font-medium">
            Avaliações
          </Link>
          <Link to="/contact" className="text-foreground hover:text-primary font-medium">
            Contato
          </Link>
        </nav>

        {/* Order Button */}
        <Button className="hidden md:block bg-primary text-white hover:bg-primary/90">
          Fazer Pedido
        </Button>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-foreground"
          onClick={toggleMenu}
          aria-label={isMenuOpen ? "Fechar menu" : "Abrir menu"}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <Link 
              to="/" 
              className="text-foreground hover:text-primary font-medium py-2"
              onClick={toggleMenu}
            >
              Início
            </Link>
            <Link 
              to="/menu" 
              className="text-foreground hover:text-primary font-medium py-2"
              onClick={toggleMenu}
            >
              Menu
            </Link>
            <Link 
              to="/about" 
              className="text-foreground hover:text-primary font-medium py-2"
              onClick={toggleMenu}
            >
              Sobre
            </Link>
            <Link 
              to="/reviews" 
              className="text-foreground hover:text-primary font-medium py-2"
              onClick={toggleMenu}
            >
              Avaliações
            </Link>
            <Link 
              to="/contact" 
              className="text-foreground hover:text-primary font-medium py-2"
              onClick={toggleMenu}
            >
              Contato
            </Link>
            <Button className="bg-primary text-white hover:bg-primary/90 w-full">
              Fazer Pedido
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;

