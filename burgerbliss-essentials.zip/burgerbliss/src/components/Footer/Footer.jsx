import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter } from 'lucide-react';
import logo from '../../assets/logo.svg';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-foreground text-background pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo e Informações */}
          <div className="col-span-1">
            <Link to="/" className="inline-block mb-4">
              <img src={logo} alt="BurgerBliss Logo" className="h-12" />
            </Link>
            <p className="text-sm mb-4">
              Uma experiência de sabor inesquecível com os melhores hambúrgueres artesanais da cidade.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-background hover:text-secondary" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-background hover:text-secondary" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-background hover:text-secondary" aria-label="Twitter">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Links Rápidos */}
          <div className="col-span-1">
            <h3 className="text-lg font-bold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-background/80 hover:text-secondary">
                  Início
                </Link>
              </li>
              <li>
                <Link to="/menu" className="text-background/80 hover:text-secondary">
                  Menu
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-background/80 hover:text-secondary">
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link to="/reviews" className="text-background/80 hover:text-secondary">
                  Avaliações
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-background/80 hover:text-secondary">
                  Contato
                </Link>
              </li>
            </ul>
          </div>

          {/* Horário de Funcionamento */}
          <div className="col-span-1">
            <h3 className="text-lg font-bold mb-4">Horário de Funcionamento</h3>
            <ul className="space-y-2">
              <li className="flex justify-between">
                <span>Segunda - Quinta:</span>
                <span>11:00 - 22:00</span>
              </li>
              <li className="flex justify-between">
                <span>Sexta - Sábado:</span>
                <span>11:00 - 23:00</span>
              </li>
              <li className="flex justify-between">
                <span>Domingo:</span>
                <span>12:00 - 22:00</span>
              </li>
            </ul>
          </div>

          {/* Contato */}
          <div className="col-span-1">
            <h3 className="text-lg font-bold mb-4">Contato</h3>
            <address className="not-italic">
              <p className="mb-2">Av. Hamburguesa, 1234</p>
              <p className="mb-2">São Paulo, SP</p>
              <p className="mb-2">CEP: 01234-567</p>
              <p className="mb-2">Telefone: (11) 1234-5678</p>
              <p className="mb-2">Email: contato@burgerbliss.com</p>
            </address>
          </div>
        </div>

        {/* Linha divisória */}
        <div className="border-t border-background/20 mt-8 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-background/60">
              &copy; {currentYear} BurgerBliss. Todos os direitos reservados.
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <Link to="/privacy" className="text-sm text-background/60 hover:text-secondary">
                Política de Privacidade
              </Link>
              <Link to="/terms" className="text-sm text-background/60 hover:text-secondary">
                Termos de Uso
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

