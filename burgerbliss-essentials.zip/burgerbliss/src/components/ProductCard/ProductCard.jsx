import { useState } from 'react';
import { ShoppingCart, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ProductCard = ({ product }) => {
  const [isHovered, setIsHovered] = useState(false);
  
  const { id, name, description, price, image, rating, category } = product;
  
  const formatPrice = (price) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };
  
  return (
    <div 
      className="card overflow-hidden transition-all duration-300 hover:shadow-lg"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Imagem do produto com efeito de zoom */}
      <div className="relative h-48 overflow-hidden rounded-t-lg">
        <img 
          src={image} 
          alt={name} 
          className={`w-full h-full object-cover transition-transform duration-500 ${isHovered ? 'scale-110' : 'scale-100'}`}
        />
        {category && (
          <span className="absolute top-2 left-2 bg-secondary text-secondary-foreground text-xs font-bold px-2 py-1 rounded">
            {category}
          </span>
        )}
        <div className="absolute top-2 right-2 flex items-center bg-background/80 backdrop-blur-sm rounded px-2 py-1">
          <Star className="h-3 w-3 text-secondary fill-secondary" />
          <span className="text-xs font-medium ml-1">{rating}</span>
        </div>
      </div>
      
      {/* Conteúdo do card */}
      <div className="p-4">
        <h3 className="text-lg font-bold mb-1">{name}</h3>
        <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{description}</p>
        
        <div className="flex items-center justify-between">
          <span className="text-lg font-bold text-primary">{formatPrice(price)}</span>
          <Button 
            size="sm" 
            className="bg-primary text-white hover:bg-primary/90 flex items-center gap-1"
          >
            <ShoppingCart className="h-4 w-4" />
            <span>Adicionar</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;

