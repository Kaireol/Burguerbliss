// Dados fictícios de produtos para o menu da hamburgueria
const products = [
  // Hambúrgueres
  {
    id: 'burger-1',
    name: 'Classic Burger',
    description: 'Hambúrguer artesanal de 180g, queijo cheddar, alface, tomate, cebola roxa e molho especial da casa.',
    price: 32.90,
    image: '/images/burgers/classic-burger.jpg',
    category: 'Hambúrgueres',
    rating: 4.8,
    featured: true,
    ingredients: ['Pão brioche', 'Hambúrguer 180g', 'Queijo cheddar', 'Alface', 'Tomate', 'Cebola roxa', 'Molho especial'],
    nutritionalInfo: {
      calories: 650,
      protein: '35g',
      carbs: '48g',
      fat: '32g'
    }
  },
  {
    id: 'burger-2',
    name: 'Cheese Bacon',
    description: 'Hambúrguer artesanal de 180g, queijo cheddar, bacon crocante, cebola caramelizada e molho barbecue.',
    price: 36.90,
    image: '/images/burgers/cheese-bacon.jpg',
    category: 'Hambúrgueres',
    rating: 4.9,
    featured: true,
    ingredients: ['Pão brioche', 'Hambúrguer 180g', 'Queijo cheddar', 'Bacon', 'Cebola caramelizada', 'Molho barbecue'],
    nutritionalInfo: {
      calories: 780,
      protein: '42g',
      carbs: '46g',
      fat: '45g'
    }
  },
  {
    id: 'burger-3',
    name: 'Veggie Supreme',
    description: 'Hambúrguer vegetal à base de grão-de-bico, queijo vegano, rúcula, tomate, cebola caramelizada e maionese vegana.',
    price: 34.90,
    image: '/images/burgers/veggie-supreme.jpg',
    category: 'Hambúrgueres',
    rating: 4.6,
    featured: false,
    ingredients: ['Pão integral', 'Hambúrguer vegetal', 'Queijo vegano', 'Rúcula', 'Tomate', 'Cebola caramelizada', 'Maionese vegana'],
    nutritionalInfo: {
      calories: 520,
      protein: '18g',
      carbs: '62g',
      fat: '22g'
    }
  },
  {
    id: 'burger-4',
    name: 'Double Trouble',
    description: 'Dois hambúrgueres artesanais de 180g, queijo cheddar duplo, bacon, picles, cebola crispy e molho especial.',
    price: 45.90,
    image: '/images/burgers/double-trouble.jpg',
    category: 'Hambúrgueres',
    rating: 4.7,
    featured: true,
    ingredients: ['Pão brioche', 'Hambúrguer 180g (2x)', 'Queijo cheddar (2x)', 'Bacon', 'Picles', 'Cebola crispy', 'Molho especial'],
    nutritionalInfo: {
      calories: 950,
      protein: '58g',
      carbs: '52g',
      fat: '62g'
    }
  },
  {
    id: 'burger-5',
    name: 'Blue Cheese',
    description: 'Hambúrguer artesanal de 180g, queijo gorgonzola, rúcula, cebola caramelizada, cogumelos salteados e maionese de ervas.',
    price: 38.90,
    image: '/images/burgers/blue-cheese.jpg',
    category: 'Hambúrgueres',
    rating: 4.5,
    featured: false,
    ingredients: ['Pão australiano', 'Hambúrguer 180g', 'Queijo gorgonzola', 'Rúcula', 'Cebola caramelizada', 'Cogumelos salteados', 'Maionese de ervas'],
    nutritionalInfo: {
      calories: 720,
      protein: '38g',
      carbs: '44g',
      fat: '42g'
    }
  },
  {
    id: 'burger-6',
    name: 'Spicy Mexican',
    description: 'Hambúrguer artesanal de 180g, queijo pepper jack, guacamole, pico de gallo, jalapeños e maionese de chipotle.',
    price: 37.90,
    image: '/images/burgers/spicy-mexican.jpg',
    category: 'Hambúrgueres',
    rating: 4.7,
    featured: false,
    ingredients: ['Pão brioche', 'Hambúrguer 180g', 'Queijo pepper jack', 'Guacamole', 'Pico de gallo', 'Jalapeños', 'Maionese de chipotle'],
    nutritionalInfo: {
      calories: 680,
      protein: '36g',
      carbs: '48g',
      fat: '38g'
    }
  },
  
  // Acompanhamentos
  {
    id: 'side-1',
    name: 'Batata Frita',
    description: 'Batatas fritas crocantes por fora e macias por dentro, temperadas com sal e ervas.',
    price: 14.90,
    image: '/images/sides/fries.jpg',
    category: 'Acompanhamentos',
    rating: 4.8,
    featured: true,
    ingredients: ['Batatas', 'Sal', 'Ervas'],
    nutritionalInfo: {
      calories: 320,
      protein: '4g',
      carbs: '42g',
      fat: '16g'
    }
  },
  {
    id: 'side-2',
    name: 'Onion Rings',
    description: 'Anéis de cebola empanados e fritos, servidos com molho barbecue.',
    price: 16.90,
    image: '/images/sides/onion-rings.jpg',
    category: 'Acompanhamentos',
    rating: 4.6,
    featured: false,
    ingredients: ['Cebola', 'Farinha de trigo', 'Temperos', 'Molho barbecue'],
    nutritionalInfo: {
      calories: 380,
      protein: '6g',
      carbs: '48g',
      fat: '18g'
    }
  },
  {
    id: 'side-3',
    name: 'Nuggets de Frango',
    description: '8 unidades de nuggets de frango empanados e fritos, servidos com molho de mostarda e mel.',
    price: 18.90,
    image: '/images/sides/chicken-nuggets.jpg',
    category: 'Acompanhamentos',
    rating: 4.5,
    featured: false,
    ingredients: ['Frango', 'Farinha de trigo', 'Temperos', 'Molho de mostarda e mel'],
    nutritionalInfo: {
      calories: 420,
      protein: '22g',
      carbs: '36g',
      fat: '22g'
    }
  },
  
  // Bebidas
  {
    id: 'drink-1',
    name: 'Refrigerante',
    description: 'Refrigerante de cola, guaraná, limão ou laranja (lata 350ml).',
    price: 6.90,
    image: '/images/drinks/soda.jpg',
    category: 'Bebidas',
    rating: 4.5,
    featured: false,
    nutritionalInfo: {
      calories: 140,
      protein: '0g',
      carbs: '39g',
      fat: '0g'
    }
  },
  {
    id: 'drink-2',
    name: 'Milkshake',
    description: 'Milkshake cremoso nos sabores chocolate, baunilha, morango ou caramelo (400ml).',
    price: 15.90,
    image: '/images/drinks/milkshake.jpg',
    category: 'Bebidas',
    rating: 4.9,
    featured: true,
    ingredients: ['Sorvete', 'Leite', 'Calda de sabor'],
    nutritionalInfo: {
      calories: 480,
      protein: '9g',
      carbs: '68g',
      fat: '18g'
    }
  },
  {
    id: 'drink-3',
    name: 'Suco Natural',
    description: 'Suco natural nos sabores laranja, limão, abacaxi ou maracujá (400ml).',
    price: 9.90,
    image: '/images/drinks/juice.jpg',
    category: 'Bebidas',
    rating: 4.7,
    featured: false,
    ingredients: ['Fruta', 'Água', 'Açúcar (opcional)'],
    nutritionalInfo: {
      calories: 120,
      protein: '1g',
      carbs: '28g',
      fat: '0g'
    }
  },
  
  // Sobremesas
  {
    id: 'dessert-1',
    name: 'Brownie com Sorvete',
    description: 'Brownie de chocolate quente com sorvete de baunilha e calda de chocolate.',
    price: 18.90,
    image: '/images/desserts/brownie.jpg',
    category: 'Sobremesas',
    rating: 4.9,
    featured: true,
    ingredients: ['Brownie de chocolate', 'Sorvete de baunilha', 'Calda de chocolate'],
    nutritionalInfo: {
      calories: 520,
      protein: '7g',
      carbs: '64g',
      fat: '26g'
    }
  },
  {
    id: 'dessert-2',
    name: 'Cheesecake',
    description: 'Cheesecake cremoso com calda de frutas vermelhas.',
    price: 16.90,
    image: '/images/desserts/cheesecake.jpg',
    category: 'Sobremesas',
    rating: 4.8,
    featured: false,
    ingredients: ['Base de biscoito', 'Cream cheese', 'Calda de frutas vermelhas'],
    nutritionalInfo: {
      calories: 450,
      protein: '8g',
      carbs: '48g',
      fat: '24g'
    }
  }
];

export default products;

