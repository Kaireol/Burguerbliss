// Dados fictícios de avaliações de clientes
const reviews = [
  // Avaliações positivas
  {
    id: 'review-1',
    customerName: 'Rafael Silva',
    customerImage: '/images/avatars/avatar1.jpg',
    date: '2025-05-28',
    rating: 5,
    productId: 'burger-1',
    productName: 'Classic Burger',
    comment: 'Simplesmente o melhor hambúrguer que já comi! A carne estava no ponto perfeito, suculenta e saborosa. O molho especial da casa é incrível e combina perfeitamente com todos os ingredientes. Atendimento rápido e equipe muito simpática. Com certeza voltarei mais vezes!',
    sentiment: 'positive',
    topics: ['sabor', 'atendimento', 'qualidade']
  },
  {
    id: 'review-2',
    customerName: 'Juliana Costa',
    customerImage: '/images/avatars/avatar2.jpg',
    date: '2025-06-01',
    rating: 5,
    productId: 'burger-2',
    productName: 'Cheese Bacon',
    comment: 'O Cheese Bacon é sensacional! O bacon estava super crocante e a cebola caramelizada dá um toque especial. O pão estava fresquinho e a carne muito bem preparada. O ambiente do restaurante também é muito agradável e aconchegante. Recomendo demais!',
    sentiment: 'positive',
    topics: ['sabor', 'ambiente', 'qualidade']
  },
  {
    id: 'review-3',
    customerName: 'Marcos Oliveira',
    customerImage: '/images/avatars/avatar3.jpg',
    date: '2025-05-15',
    rating: 5,
    productId: 'dessert-1',
    productName: 'Brownie com Sorvete',
    comment: 'A sobremesa perfeita depois de um hambúrguer delicioso! O brownie estava quentinho e o contraste com o sorvete gelado é maravilhoso. A calda de chocolate é generosa e muito saborosa. Vale cada centavo!',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'valor']
  },
  {
    id: 'review-4',
    customerName: 'Fernanda Lima',
    customerImage: '/images/avatars/avatar4.jpg',
    date: '2025-05-20',
    rating: 4,
    productId: 'burger-4',
    productName: 'Double Trouble',
    comment: 'Hambúrguer muito saboroso e bem servido! As duas carnes estavam bem preparadas e suculentas. O único ponto negativo é que achei um pouco caro para o que oferece, mas a qualidade é inegável. O atendimento foi excelente e rápido.',
    sentiment: 'positive',
    topics: ['sabor', 'atendimento', 'preço']
  },
  {
    id: 'review-5',
    customerName: 'Pedro Mendes',
    customerImage: '/images/avatars/avatar5.jpg',
    date: '2025-05-25',
    rating: 5,
    productId: 'burger-6',
    productName: 'Spicy Mexican',
    comment: 'Para quem gosta de comida apimentada, o Spicy Mexican é perfeito! O nível de picância está excelente, dá aquela ardidinha gostosa sem exagerar. O guacamole fresco faz toda a diferença. Os ingredientes são de alta qualidade e o hambúrguer é bem montado. Já virei cliente fiel!',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'apresentação']
  },
  {
    id: 'review-6',
    customerName: 'Camila Santos',
    customerImage: '/images/avatars/avatar6.jpg',
    date: '2025-06-02',
    rating: 5,
    productId: 'drink-2',
    productName: 'Milkshake',
    comment: 'O milkshake de chocolate é divino! Cremoso na medida certa, não é enjoativo e tem um sabor intenso de chocolate. Combinação perfeita com os hambúrgueres. O tamanho da porção também é generoso. Adorei!',
    sentiment: 'positive',
    topics: ['sabor', 'porção', 'qualidade']
  },
  
  // Avaliações neutras
  {
    id: 'review-7',
    customerName: 'Lucas Ferreira',
    customerImage: '/images/avatars/avatar7.jpg',
    date: '2025-05-18',
    rating: 3,
    productId: 'burger-3',
    productName: 'Veggie Supreme',
    comment: 'O hambúrguer vegetal tem um sabor interessante, mas achei a textura um pouco estranha. Os acompanhamentos estavam frescos e o pão estava bom. Acho que poderiam melhorar a receita do hambúrguer em si. O atendimento foi bom e o ambiente é agradável.',
    sentiment: 'neutral',
    topics: ['sabor', 'textura', 'ambiente']
  },
  {
    id: 'review-8',
    customerName: 'Beatriz Almeida',
    customerImage: '/images/avatars/avatar8.jpg',
    date: '2025-05-22',
    rating: 3,
    productId: 'side-2',
    productName: 'Onion Rings',
    comment: 'As onion rings estavam crocantes, mas um pouco oleosas demais para o meu gosto. O molho barbecue que acompanha é bom, mas nada excepcional. Acho que o preço está um pouco alto para a quantidade servida.',
    sentiment: 'neutral',
    topics: ['qualidade', 'preço', 'porção']
  },
  {
    id: 'review-9',
    customerName: 'Gustavo Martins',
    customerImage: '/images/avatars/avatar9.jpg',
    date: '2025-05-30',
    rating: 3,
    productId: 'burger-5',
    productName: 'Blue Cheese',
    comment: 'O hambúrguer com queijo gorgonzola é uma opção diferente, mas o sabor do queijo acaba dominando muito. Para quem gosta de gorgonzola deve ser ótimo, mas para mim foi um pouco intenso demais. A carne estava bem preparada e os outros ingredientes frescos. O atendimento foi bom.',
    sentiment: 'neutral',
    topics: ['sabor', 'atendimento', 'qualidade']
  },
  
  // Avaliações negativas
  {
    id: 'review-10',
    customerName: 'Amanda Rodrigues',
    customerImage: '/images/avatars/avatar10.jpg',
    date: '2025-05-17',
    rating: 2,
    productId: 'side-3',
    productName: 'Nuggets de Frango',
    comment: 'Os nuggets estavam muito secos e com pouco sabor. O molho de mostarda e mel não conseguiu salvar. Achei caro para a qualidade oferecida. O atendimento foi bom, mas o produto deixou a desejar.',
    sentiment: 'negative',
    topics: ['qualidade', 'sabor', 'preço']
  },
  {
    id: 'review-11',
    customerName: 'Ricardo Gomes',
    customerImage: '/images/avatars/avatar11.jpg',
    date: '2025-05-29',
    rating: 2,
    productId: 'burger-1',
    productName: 'Classic Burger',
    comment: 'Fiquei desapontado com o tempo de espera. Demorou quase 40 minutos para o hambúrguer chegar à mesa, e quando chegou, estava morno. O sabor até que é bom, mas a experiência foi prejudicada pela demora e pela temperatura do lanche.',
    sentiment: 'negative',
    topics: ['tempo de espera', 'temperatura', 'atendimento']
  },
  {
    id: 'review-12',
    customerName: 'Carla Pereira',
    customerImage: '/images/avatars/avatar12.jpg',
    date: '2025-05-26',
    rating: 1,
    productId: 'burger-2',
    productName: 'Cheese Bacon',
    comment: 'Tive uma experiência terrível. O hambúrguer veio com a carne mal passada, mesmo tendo pedido ao ponto. O bacon estava queimado e o pão um pouco duro. Quando reclamei, demoraram para resolver o problema. Não voltarei e não recomendo.',
    sentiment: 'negative',
    topics: ['qualidade', 'atendimento', 'preparo']
  },
  
  // Mais avaliações positivas
  {
    id: 'review-13',
    customerName: 'Daniel Souza',
    customerImage: '/images/avatars/avatar13.jpg',
    date: '2025-06-03',
    rating: 5,
    productId: 'burger-4',
    productName: 'Double Trouble',
    comment: 'Que hambúrguer incrível! As duas carnes estavam suculentas e no ponto perfeito. A combinação de ingredientes é sensacional e o molho especial complementa muito bem. Vale cada centavo! O ambiente é muito agradável e o atendimento foi excelente.',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'atendimento', 'ambiente']
  },
  {
    id: 'review-14',
    customerName: 'Mariana Costa',
    customerImage: '/images/avatars/avatar14.jpg',
    date: '2025-05-31',
    rating: 4,
    productId: 'side-1',
    productName: 'Batata Frita',
    comment: 'As batatas fritas estão entre as melhores que já comi! Crocantes por fora e macias por dentro, bem temperadas. A porção é generosa e o preço justo. Só não dou 5 estrelas porque vieram um pouco oleosas demais.',
    sentiment: 'positive',
    topics: ['sabor', 'porção', 'preço', 'qualidade']
  },
  {
    id: 'review-15',
    customerName: 'Bruno Oliveira',
    customerImage: '/images/avatars/avatar15.jpg',
    date: '2025-05-24',
    rating: 5,
    productId: 'dessert-2',
    productName: 'Cheesecake',
    comment: 'O cheesecake é simplesmente divino! Cremoso na medida certa, com uma base crocante e uma calda de frutas vermelhas deliciosa. Uma das melhores sobremesas que já provei. Recomendo muito para finalizar a refeição com chave de ouro!',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'textura']
  },
  {
    id: 'review-16',
    customerName: 'Patrícia Lima',
    customerImage: '/images/avatars/avatar16.jpg',
    date: '2025-05-19',
    rating: 4,
    productId: 'burger-6',
    productName: 'Spicy Mexican',
    comment: 'Adoro comida mexicana e esse hambúrguer não decepcionou! O nível de picância está bom, dá para sentir o sabor dos ingredientes. O guacamole estava fresco e saboroso. O único ponto negativo é que o pão estava um pouco seco. De resto, excelente!',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'ingredientes']
  },
  
  // Mais avaliações neutras
  {
    id: 'review-17',
    customerName: 'Felipe Santos',
    customerImage: '/images/avatars/avatar17.jpg',
    date: '2025-05-27',
    rating: 3,
    productId: 'drink-1',
    productName: 'Refrigerante',
    comment: 'O refrigerante estava gelado, mas achei o preço um pouco alto para uma lata de 350ml. Nada de especial, é o mesmo refrigerante que encontramos em qualquer lugar. Poderiam oferecer opções de refil ou tamanhos maiores por um preço mais acessível.',
    sentiment: 'neutral',
    topics: ['preço', 'porção', 'valor']
  },
  {
    id: 'review-18',
    customerName: 'Renata Alves',
    customerImage: '/images/avatars/avatar18.jpg',
    date: '2025-05-23',
    rating: 3,
    productId: 'burger-3',
    productName: 'Veggie Supreme',
    comment: 'Como vegetariana, aprecio que tenham opções no cardápio. O hambúrguer vegetal tem um sabor razoável, mas já provei melhores. Os acompanhamentos estavam frescos e o molho era bom. Acho que poderiam melhorar a receita do hambúrguer ou oferecer mais opções vegetarianas.',
    sentiment: 'neutral',
    topics: ['opções vegetarianas', 'sabor', 'variedade']
  },
  
  // Mais avaliações negativas
  {
    id: 'review-19',
    customerName: 'Thiago Moreira',
    customerImage: '/images/avatars/avatar19.jpg',
    date: '2025-05-21',
    rating: 2,
    productId: 'burger-5',
    productName: 'Blue Cheese',
    comment: 'Fiquei decepcionado com este hambúrguer. O queijo gorgonzola estava muito forte e dominava completamente o sabor da carne. Os cogumelos estavam muito oleosos e o pão um pouco mole. O atendimento foi bom, mas o produto deixou a desejar.',
    sentiment: 'negative',
    topics: ['sabor', 'qualidade', 'preparo']
  },
  {
    id: 'review-20',
    customerName: 'Luciana Ferreira',
    customerImage: '/images/avatars/avatar20.jpg',
    date: '2025-06-04',
    rating: 1,
    productId: 'side-1',
    productName: 'Batata Frita',
    comment: 'Péssima experiência. As batatas estavam frias e moles, claramente não eram frescas. Quando pedi para trocar, demoraram muito e as novas batatas vieram igualmente ruins. O preço é alto para a qualidade oferecida. Não recomendo.',
    sentiment: 'negative',
    topics: ['qualidade', 'temperatura', 'atendimento', 'preço']
  },
  
  // Avaliações adicionais
  {
    id: 'review-21',
    customerName: 'Eduardo Nunes',
    customerImage: '/images/avatars/avatar21.jpg',
    date: '2025-06-05',
    rating: 5,
    productId: 'burger-1',
    productName: 'Classic Burger',
    comment: 'Hambúrguer clássico perfeito! Todos os ingredientes estavam frescos e a carne no ponto ideal. O molho da casa é um diferencial e combina perfeitamente com o conjunto. O atendimento foi rápido e atencioso. Já estou planejando voltar para experimentar outros itens do cardápio!',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'atendimento']
  },
  {
    id: 'review-22',
    customerName: 'Isabela Martins',
    customerImage: '/images/avatars/avatar22.jpg',
    date: '2025-05-16',
    rating: 4,
    productId: 'drink-3',
    productName: 'Suco Natural',
    comment: 'O suco de maracujá estava muito saboroso e refrescante. Dava para sentir que era natural mesmo, sem aquele gosto artificial. A única sugestão seria oferecer a opção sem açúcar. Mas no geral, muito bom!',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'opções']
  },
  {
    id: 'review-23',
    customerName: 'Rodrigo Almeida',
    customerImage: '/images/avatars/avatar23.jpg',
    date: '2025-06-06',
    rating: 2,
    productId: 'burger-4',
    productName: 'Double Trouble',
    comment: 'Esperava muito mais deste hambúrguer duplo pelo preço cobrado. As carnes estavam secas e sem muito sabor. O bacon não estava crocante e havia pouco queijo. O atendimento foi bom, mas a qualidade da comida deixou a desejar.',
    sentiment: 'negative',
    topics: ['qualidade', 'preço', 'valor']
  },
  {
    id: 'review-24',
    customerName: 'Aline Cardoso',
    customerImage: '/images/avatars/avatar24.jpg',
    date: '2025-05-14',
    rating: 5,
    productId: 'burger-2',
    productName: 'Cheese Bacon',
    comment: 'Simplesmente o melhor Cheese Bacon que já comi! O bacon estava no ponto perfeito de crocância e a cebola caramelizada dá um toque especial. A carne estava suculenta e o queijo derretido na medida certa. Ambiente agradável e atendimento excelente!',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'ambiente', 'atendimento']
  },
  {
    id: 'review-25',
    customerName: 'Vinícius Torres',
    customerImage: '/images/avatars/avatar25.jpg',
    date: '2025-06-07',
    rating: 3,
    productId: 'dessert-1',
    productName: 'Brownie com Sorvete',
    comment: 'O brownie estava bom, mas um pouco seco. O sorvete era de boa qualidade e a calda de chocolate saborosa. Acho que poderiam melhorar a textura do brownie para ficar mais úmido. O preço está um pouco alto para o tamanho da porção.',
    sentiment: 'neutral',
    topics: ['qualidade', 'textura', 'preço', 'porção']
  },
  {
    id: 'review-26',
    customerName: 'Carolina Mendes',
    customerImage: '/images/avatars/avatar26.jpg',
    date: '2025-05-13',
    rating: 4,
    productId: 'side-3',
    productName: 'Nuggets de Frango',
    comment: 'Os nuggets estavam crocantes e saborosos. O molho de mostarda e mel é uma combinação interessante e funciona bem. Só achei que a porção poderia ser um pouco maior pelo preço cobrado, mas a qualidade é boa.',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'porção', 'preço']
  },
  {
    id: 'review-27',
    customerName: 'Marcelo Dias',
    customerImage: '/images/avatars/avatar27.jpg',
    date: '2025-06-08',
    rating: 1,
    productId: 'burger-6',
    productName: 'Spicy Mexican',
    comment: 'Péssima experiência! O hambúrguer estava extremamente apimentado, a ponto de não conseguir sentir o sabor dos outros ingredientes. Quando mencionei ao garçom, ele foi grosseiro e disse que era assim mesmo. Não voltarei e não recomendo.',
    sentiment: 'negative',
    topics: ['sabor', 'atendimento', 'preparo']
  },
  {
    id: 'review-28',
    customerName: 'Tatiana Lopes',
    customerImage: '/images/avatars/avatar28.jpg',
    date: '2025-05-12',
    rating: 5,
    productId: 'drink-2',
    productName: 'Milkshake',
    comment: 'O milkshake de morango é simplesmente divino! Cremoso, com pedaços de fruta de verdade e no ponto certo de doçura. Combina perfeitamente com os hambúrgueres. A apresentação também é linda! Vale cada centavo.',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'apresentação', 'valor']
  },
  {
    id: 'review-29',
    customerName: 'Leonardo Castro',
    customerImage: '/images/avatars/avatar29.jpg',
    date: '2025-06-09',
    rating: 3,
    productId: 'side-2',
    productName: 'Onion Rings',
    comment: 'As onion rings estavam crocantes, mas um pouco oleosas. O molho barbecue que acompanha é bom. Acho que o preço está um pouco alto para a quantidade servida, mas a qualidade é razoável.',
    sentiment: 'neutral',
    topics: ['qualidade', 'preço', 'porção']
  },
  {
    id: 'review-30',
    customerName: 'Bianca Oliveira',
    customerImage: '/images/avatars/avatar30.jpg',
    date: '2025-05-11',
    rating: 5,
    productId: 'dessert-2',
    productName: 'Cheesecake',
    comment: 'O cheesecake é maravilhoso! Cremoso, com a acidez na medida certa e a calda de frutas vermelhas complementa perfeitamente. A base está crocante e o doce não é enjoativo. Uma das melhores sobremesas que já provei! Recomendo muito!',
    sentiment: 'positive',
    topics: ['sabor', 'qualidade', 'textura']
  }
];

export default reviews;

