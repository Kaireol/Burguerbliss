/**
 * Gerador de avatares SVG para os clientes fictícios
 * 
 * Este utilitário cria avatares SVG simples com iniciais para os clientes
 * quando as imagens reais não estiverem disponíveis.
 */

/**
 * Gera um avatar SVG com as iniciais do nome
 * @param {string} name - Nome completo do cliente
 * @param {number} size - Tamanho do avatar em pixels
 * @returns {string} - String do SVG gerado
 */
export const generateAvatar = (name, size = 200) => {
  // Extrai as iniciais do nome
  const initials = name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);
  
  // Gera uma cor baseada no nome
  const hue = Math.abs(name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) % 360);
  const bgColor = `hsl(${hue}, 70%, 60%)`;
  
  // Cria o SVG
  return `
    <svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
      <rect width="${size}" height="${size}" fill="${bgColor}" />
      <text 
        x="50%" 
        y="50%" 
        dy=".1em" 
        fill="white" 
        font-family="Arial, sans-serif" 
        font-size="${size * 0.4}px" 
        font-weight="bold" 
        text-anchor="middle" 
        dominant-baseline="middle"
      >
        ${initials}
      </text>
    </svg>
  `;
};

/**
 * Converte um SVG para uma URL de dados
 * @param {string} svg - String do SVG
 * @returns {string} - URL de dados do SVG
 */
export const svgToDataUrl = (svg) => {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
};

/**
 * Gera uma URL de avatar para um cliente
 * @param {string} name - Nome do cliente
 * @param {string} [imagePath] - Caminho da imagem (opcional)
 * @returns {string} - URL da imagem ou URL de dados do SVG
 */
export const getAvatarUrl = (name, imagePath) => {
  if (imagePath && !imagePath.includes('avatar')) {
    return imagePath;
  }
  
  const svg = generateAvatar(name);
  return svgToDataUrl(svg);
};

export default {
  generateAvatar,
  svgToDataUrl,
  getAvatarUrl
};

