import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Search } from 'lucide-react';
import ProductCard from '@/components/ProductCard/ProductCard';
import products from '@/data/products';

const Menu = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredProducts, setFilteredProducts] = useState([]);
  
  // Obter categorias únicas
  const categories = ['Hambúrgueres', 'Acompanhamentos', 'Bebidas', 'Sobremesas'];
  
  // Filtrar produtos com base na categoria e pesquisa
  useEffect(() => {
    let result = [...products];
    
    // Filtrar por categoria
    if (activeCategory !== 'all') {
      result = result.filter(product => product.category === activeCategory);
    }
    
    // Filtrar por pesquisa
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      result = result.filter(product => 
        product.name.toLowerCase().includes(query) || 
        product.description.toLowerCase().includes(query)
      );
    }
    
    setFilteredProducts(result);
  }, [activeCategory, searchQuery]);
  
  // Manipular mudança de categoria
  const handleCategoryChange = (category) => {
    setActiveCategory(category);
  };
  
  // Manipular pesquisa
  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };
  
  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Nosso Cardápio</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Descubra nossos deliciosos hambúrgueres artesanais e acompanhamentos. 
            Todos preparados com ingredientes frescos e de alta qualidade.
          </p>
        </div>
        
        {/* Barra de pesquisa */}
        <div className="max-w-md mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
            <Input
              type="text"
              placeholder="Pesquisar no cardápio..."
              value={searchQuery}
              onChange={handleSearch}
              className="pl-10"
            />
          </div>
        </div>
        
        {/* Tabs de categorias */}
        <Tabs defaultValue="all" value={activeCategory} onValueChange={handleCategoryChange} className="mb-8">
          <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full">
            <TabsTrigger value="all">Todos</TabsTrigger>
            {categories.map(category => (
              <TabsTrigger key={category} value={category}>
                {category}
              </TabsTrigger>
            ))}
          </TabsList>
          
          <TabsContent value="all" className="mt-6">
            {/* Seção de Hambúrgueres */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold mb-6 border-b pb-2">Hambúrgueres</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts
                  .filter(product => product.category === 'Hambúrgueres')
                  .map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </div>
            
            {/* Seção de Acompanhamentos */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold mb-6 border-b pb-2">Acompanhamentos</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts
                  .filter(product => product.category === 'Acompanhamentos')
                  .map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </div>
            
            {/* Seção de Bebidas */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold mb-6 border-b pb-2">Bebidas</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts
                  .filter(product => product.category === 'Bebidas')
                  .map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </div>
            
            {/* Seção de Sobremesas */}
            <div>
              <h2 className="text-2xl font-bold mb-6 border-b pb-2">Sobremesas</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts
                  .filter(product => product.category === 'Sobremesas')
                  .map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </div>
          </TabsContent>
          
          {/* Conteúdo para cada categoria */}
          {categories.map(category => (
            <TabsContent key={category} value={category} className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts
                  .filter(product => product.category === category)
                  .map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
              
              {/* Mensagem quando não há produtos */}
              {filteredProducts.filter(product => product.category === category).length === 0 && (
                <div className="text-center py-12 bg-muted/30 rounded-lg">
                  <p className="text-lg text-muted-foreground">
                    Nenhum produto encontrado para esta categoria com os filtros atuais.
                  </p>
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
        
        {/* Mensagem quando não há produtos */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-12 bg-muted/30 rounded-lg">
            <p className="text-lg text-muted-foreground">
              Nenhum produto encontrado com os filtros atuais.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Menu;

