import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CheckCircle, Users, Clock, Leaf } from 'lucide-react';

const About = () => {
  // Valores da empresa
  const values = [
    {
      icon: <CheckCircle className="h-8 w-8 text-primary" />,
      title: 'Qualidade',
      description: 'Utilizamos apenas ingredientes frescos e de alta qualidade, selecionados diariamente para garantir o melhor sabor em cada hambúrguer.'
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: 'Atendimento',
      description: 'Nossa equipe é treinada para oferecer um atendimento excepcional, garantindo que cada cliente tenha uma experiência memorável.'
    },
    {
      icon: <Clock className="h-8 w-8 text-primary" />,
      title: 'Eficiência',
      description: 'Trabalhamos para que seu pedido seja preparado com agilidade, sem comprometer a qualidade dos nossos produtos.'
    },
    {
      icon: <Leaf className="h-8 w-8 text-primary" />,
      title: 'Sustentabilidade',
      description: 'Comprometidos com o meio ambiente, utilizamos embalagens biodegradáveis e trabalhamos com fornecedores locais.'
    }
  ];
  
  // Linha do tempo
  const timeline = [
    {
      year: '2020',
      title: 'O Início',
      description: 'A BurgerBliss nasceu da paixão de dois amigos por hambúrgueres artesanais. Começamos com um food truck que rapidamente se tornou popular na cidade.'
    },
    {
      year: '2021',
      title: 'Primeira Loja',
      description: 'Com o sucesso do food truck, abrimos nossa primeira loja física, trazendo um ambiente aconchegante para nossos clientes.'
    },
    {
      year: '2022',
      title: 'Expansão do Cardápio',
      description: 'Expandimos nosso cardápio com novas criações, incluindo opções vegetarianas e veganas para atender a todos os gostos.'
    },
    {
      year: '2023',
      title: 'Prêmio Local',
      description: 'Fomos eleitos a melhor hamburgueria da cidade pelo segundo ano consecutivo, um reconhecimento do nosso compromisso com a qualidade.'
    },
    {
      year: '2024',
      title: 'Segunda Unidade',
      description: 'Inauguramos nossa segunda unidade, levando o sabor BurgerBliss para mais pessoas.'
    },
    {
      year: '2025',
      title: 'Hoje',
      description: 'Continuamos crescendo e inovando, sempre com o objetivo de proporcionar a melhor experiência para nossos clientes.'
    }
  ];
  
  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold mb-4">Sobre a BurgerBliss</h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Conheça nossa história, valores e o que nos torna a hamburgueria favorita da cidade.
            Descubra a paixão por hambúrgueres artesanais que nos move todos os dias.
          </p>
        </div>
        
        {/* História e Imagem */}
        <div className="flex flex-col lg:flex-row items-center gap-12 mb-16">
          <div className="lg:w-1/2">
            <h2 className="text-3xl font-bold mb-6">Nossa História</h2>
            <p className="text-lg mb-4">
              A BurgerBliss nasceu em 2020, da paixão de dois amigos, Carlos e Mariana, por hambúrgueres artesanais. 
              Após anos trabalhando em restaurantes renomados, eles decidiram unir suas experiências e criar algo único.
            </p>
            <p className="text-lg mb-4">
              Começamos com um food truck que rapidamente se tornou popular na cidade. O segredo? 
              Ingredientes frescos, carnes selecionadas e um atendimento que faz cada cliente se sentir especial.
            </p>
            <p className="text-lg mb-4">
              Com o sucesso do food truck, abrimos nossa primeira loja física em 2021, trazendo um ambiente aconchegante 
              para nossos clientes. Desde então, não paramos de crescer, sempre mantendo a qualidade e o sabor que nos tornaram famosos.
            </p>
            <p className="text-lg">
              Hoje, contamos com duas unidades e planos de expansão, mas nosso compromisso continua o mesmo: 
              proporcionar uma experiência gastronômica inesquecível a cada hambúrguer servido.
            </p>
          </div>
          <div className="lg:w-1/2">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-full h-full bg-primary rounded-lg"></div>
              <img 
                src="/images/burgers/double-trouble.jpg" 
                alt="Nossa História" 
                className="relative z-10 rounded-lg w-full h-auto"
              />
            </div>
          </div>
        </div>
        
        {/* Valores */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold mb-10 text-center">Nossos Valores</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-card shadow-sm rounded-lg p-6 text-center hover:shadow-md transition-shadow">
                <div className="flex justify-center mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                <p className="text-muted-foreground">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
        
        {/* Timeline */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold mb-10 text-center">Nossa Trajetória</h2>
          <div className="relative">
            {/* Linha central */}
            <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-muted"></div>
            
            {/* Eventos da timeline */}
            <div className="space-y-12">
              {timeline.map((event, index) => (
                <div key={index} className={`flex flex-col md:flex-row ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                  <div className="md:w-1/2"></div>
                  <div className="relative flex justify-center md:justify-start">
                    <div className="hidden md:flex items-center justify-center w-12 h-12 rounded-full bg-primary text-white font-bold absolute top-0 md:top-1/2 left-1/2 transform -translate-x-1/2 md:-translate-y-1/2 z-10">
                      {event.year.substring(2)}
                    </div>
                  </div>
                  <div className="md:w-1/2 p-4">
                    <div className="bg-card shadow-sm rounded-lg p-6 hover:shadow-md transition-shadow">
                      <div className="md:hidden flex items-center mb-2">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-white font-bold mr-2">
                          {event.year.substring(2)}
                        </div>
                        <h3 className="text-xl font-bold">{event.year} - {event.title}</h3>
                      </div>
                      <h3 className="hidden md:block text-xl font-bold mb-2">{event.year} - {event.title}</h3>
                      <p className="text-muted-foreground">{event.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Equipe */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold mb-10 text-center">Nossa Equipe</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Membro 1 */}
            <div className="bg-card shadow-sm rounded-lg overflow-hidden hover:shadow-md transition-shadow">
              <img 
                src="/images/avatars/avatar1.jpg" 
                alt="Carlos Silva" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-1">Carlos Silva</h3>
                <p className="text-primary mb-3">Co-fundador & Chef</p>
                <p className="text-muted-foreground">
                  Com mais de 15 anos de experiência na gastronomia, Carlos é o responsável por criar as receitas exclusivas da BurgerBliss.
                </p>
              </div>
            </div>
            
            {/* Membro 2 */}
            <div className="bg-card shadow-sm rounded-lg overflow-hidden hover:shadow-md transition-shadow">
              <img 
                src="/images/avatars/avatar2.jpg" 
                alt="Mariana Costa" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-1">Mariana Costa</h3>
                <p className="text-primary mb-3">Co-fundadora & Gerente</p>
                <p className="text-muted-foreground">
                  Especialista em gestão de restaurantes, Mariana garante que a experiência do cliente seja sempre excepcional.
                </p>
              </div>
            </div>
            
            {/* Membro 3 */}
            <div className="bg-card shadow-sm rounded-lg overflow-hidden hover:shadow-md transition-shadow">
              <img 
                src="/images/avatars/avatar3.jpg" 
                alt="Rafael Oliveira" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-1">Rafael Oliveira</h3>
                <p className="text-primary mb-3">Chef de Cozinha</p>
                <p className="text-muted-foreground">
                  Com um talento natural para combinar sabores, Rafael é responsável por manter o padrão de qualidade de todos os hambúrgueres.
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* CTA */}
        <div className="bg-primary text-primary-foreground rounded-lg p-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Venha nos Conhecer</h2>
          <p className="text-lg mb-6 max-w-2xl mx-auto">
            Estamos esperando por você para proporcionar uma experiência gastronômica inesquecível. 
            Venha conhecer a BurgerBliss e descubra por que somos a hamburgueria favorita da cidade.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-background text-foreground hover:bg-background/90"
              asChild
            >
              <Link to="/menu">Ver Cardápio</Link>
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-background text-background hover:bg-background/10"
              asChild
            >
              <Link to="/contact">Como Chegar</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;

