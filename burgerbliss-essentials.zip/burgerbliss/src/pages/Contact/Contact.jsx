import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Facebook, 
  Instagram, 
  Twitter,
  CheckCircle
} from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  
  const [formSubmitted, setFormSubmitted] = useState(false);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    // Simulando envio do formulário
    setTimeout(() => {
      setFormSubmitted(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: ''
      });
    }, 1000);
  };
  
  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Entre em Contato</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Estamos sempre à disposição para ouvir você. Entre em contato conosco para dúvidas, 
            sugestões, reservas ou qualquer outra informação.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Informações de Contato */}
          <div>
            <h2 className="text-2xl font-bold mb-6">Informações de Contato</h2>
            
            <div className="space-y-6">
              {/* Endereço */}
              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Endereço</h3>
                  <p className="text-muted-foreground">
                    Av. Hamburguesa, 1234<br />
                    São Paulo, SP<br />
                    CEP: 01234-567
                  </p>
                </div>
              </div>
              
              {/* Telefone */}
              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Phone className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Telefone</h3>
                  <p className="text-muted-foreground">
                    (11) 1234-5678<br />
                    (11) 98765-4321 (WhatsApp)
                  </p>
                </div>
              </div>
              
              {/* Email */}
              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Mail className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Email</h3>
                  <p className="text-muted-foreground">
                    contato@burgerbliss.com<br />
                    reservas@burgerbliss.com
                  </p>
                </div>
              </div>
              
              {/* Horário de Funcionamento */}
              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Horário de Funcionamento</h3>
                  <p className="text-muted-foreground">
                    Segunda - Quinta: 11:00 - 22:00<br />
                    Sexta - Sábado: 11:00 - 23:00<br />
                    Domingo: 12:00 - 22:00
                  </p>
                </div>
              </div>
            </div>
            
            {/* Redes Sociais */}
            <div className="mt-8">
              <h3 className="font-bold mb-4">Siga-nos nas Redes Sociais</h3>
              <div className="flex space-x-4">
                <a 
                  href="#" 
                  className="bg-foreground text-background p-3 rounded-full hover:bg-primary transition-colors"
                  aria-label="Facebook"
                >
                  <Facebook className="h-5 w-5" />
                </a>
                <a 
                  href="#" 
                  className="bg-foreground text-background p-3 rounded-full hover:bg-primary transition-colors"
                  aria-label="Instagram"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a 
                  href="#" 
                  className="bg-foreground text-background p-3 rounded-full hover:bg-primary transition-colors"
                  aria-label="Twitter"
                >
                  <Twitter className="h-5 w-5" />
                </a>
              </div>
            </div>
            
            {/* Mapa */}
            <div className="mt-8">
              <h3 className="font-bold mb-4">Como Chegar</h3>
              <div className="bg-muted h-[300px] rounded-lg flex items-center justify-center">
                <p className="text-muted-foreground">Mapa será carregado aqui</p>
              </div>
            </div>
          </div>
          
          {/* Formulário de Contato */}
          <div>
            <h2 className="text-2xl font-bold mb-6">Envie uma Mensagem</h2>
            
            {formSubmitted ? (
              <div className="bg-accent/10 border border-accent rounded-lg p-6 text-center">
                <div className="flex justify-center mb-4">
                  <CheckCircle className="h-12 w-12 text-accent" />
                </div>
                <h3 className="text-xl font-bold mb-2">Mensagem Enviada!</h3>
                <p className="text-muted-foreground mb-4">
                  Obrigado por entrar em contato conosco. Responderemos o mais breve possível.
                </p>
                <Button 
                  onClick={() => setFormSubmitted(false)}
                  className="bg-accent text-accent-foreground hover:bg-accent/90"
                >
                  Enviar Nova Mensagem
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block font-medium mb-1">
                    Nome Completo
                  </label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Seu nome completo"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="email" className="block font-medium mb-1">
                      Email
                    </label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="seu.email@exemplo.com"
                      required
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="phone" className="block font-medium mb-1">
                      Telefone
                    </label>
                    <Input
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="(00) 00000-0000"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="subject" className="block font-medium mb-1">
                    Assunto
                  </label>
                  <Input
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="Assunto da mensagem"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block font-medium mb-1">
                    Mensagem
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Digite sua mensagem aqui..."
                    rows={6}
                    required
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="bg-primary text-white hover:bg-primary/90 w-full"
                >
                  Enviar Mensagem
                </Button>
              </form>
            )}
          </div>
        </div>
        
        {/* FAQ */}
        <div>
          <h2 className="text-2xl font-bold mb-6 text-center">Perguntas Frequentes</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-card shadow-sm rounded-lg p-6">
              <h3 className="font-bold mb-2">Vocês aceitam reservas?</h3>
              <p className="text-muted-foreground">
                Sim, aceitamos reservas para grupos de 6 ou mais pessoas. Entre em contato pelo telefone ou email para fazer sua reserva.
              </p>
            </div>
            
            <div className="bg-card shadow-sm rounded-lg p-6">
              <h3 className="font-bold mb-2">Vocês fazem entregas?</h3>
              <p className="text-muted-foreground">
                Sim, fazemos entregas através dos principais aplicativos de delivery ou pelo nosso próprio sistema de delivery.
              </p>
            </div>
            
            <div className="bg-card shadow-sm rounded-lg p-6">
              <h3 className="font-bold mb-2">Vocês têm opções vegetarianas?</h3>
              <p className="text-muted-foreground">
                Sim, temos opções vegetarianas e veganas em nosso cardápio. Consulte a seção de hambúrgueres para conhecer nossas opções.
              </p>
            </div>
            
            <div className="bg-card shadow-sm rounded-lg p-6">
              <h3 className="font-bold mb-2">Vocês aceitam todos os cartões?</h3>
              <p className="text-muted-foreground">
                Sim, aceitamos as principais bandeiras de cartões de crédito e débito, além de dinheiro e PIX.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;

