import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProductCard from '@/components/ProductCard/ProductCard';
import ReviewCard from '@/components/ReviewCard/ReviewCard';
import products from '@/data/products';
import reviews from '@/data/reviews';
import { getAvatarUrl } from '@/utils/avatarGenerator';

const Home = () => {
  // Obter produtos em destaque
  const featuredProducts = products.filter(product => product.featured).slice(0, 4);
  
  // Obter avaliações recentes com 5 estrelas
  const topReviews = reviews
    .filter(review => review.rating === 5)
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 3)
    .map(review => ({
      ...review,
      customerImage: getAvatarUrl(review.customerName, review.customerImage)
    }));
  
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-foreground text-background py-20">
        <div className="container mx-auto px-4 flex flex-col lg:flex-row items-center">
          <div className="lg:w-1/2 mb-10 lg:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              Uma experiência de sabor inesquecível
            </h1>
            <p className="text-lg md:text-xl mb-8 text-background/80">
              Hambúrgueres artesanais preparados com ingredientes selecionados e muito amor. 
              Venha conhecer a BurgerBliss e se apaixone pelo nosso sabor único.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                size="lg" 
                className="bg-primary text-white hover:bg-primary/90"
                asChild
              >
                <Link to="/menu">Ver Cardápio</Link>
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-background text-background hover:bg-background/10"
                asChild
              >
                <Link to="/contact">Fazer Reserva</Link>
              </Button>
            </div>
          </div>
          <div className="lg:w-1/2 relative">
            <div className="relative w-full h-[400px] rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 mix-blend-overlay z-10"></div>
              <img 
                src="/images/burgers/classic-burger.jpg" 
                alt="Hambúrguer Artesanal" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-secondary text-secondary-foreground p-4 rounded-lg shadow-lg z-20">
              <div className="text-2xl font-bold">Novo!</div>
              <div className="text-lg">Double Trouble</div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Featured Products */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-bold">Destaques do Menu</h2>
            <Link 
              to="/menu" 
              className="flex items-center text-primary hover:text-primary/80 font-medium"
            >
              Ver Cardápio Completo
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>
      
      {/* About Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <div className="lg:w-1/2">
              <h2 className="text-3xl font-bold mb-6">Sobre a BurgerBliss</h2>
              <p className="text-lg mb-6 text-muted-foreground">
                Fundada em 2020, a BurgerBliss nasceu da paixão por hambúrgueres artesanais e da vontade de oferecer uma experiência gastronômica única aos nossos clientes.
              </p>
              <p className="text-lg mb-6 text-muted-foreground">
                Utilizamos apenas ingredientes frescos e de alta qualidade, selecionados diariamente. Nossas receitas exclusivas foram desenvolvidas para proporcionar uma explosão de sabores em cada mordida.
              </p>
              <Button 
                className="bg-primary text-white hover:bg-primary/90"
                asChild
              >
                <Link to="/about">Conheça Nossa História</Link>
              </Button>
            </div>
            <div className="lg:w-1/2 grid grid-cols-2 gap-4">
              <div className="rounded-lg overflow-hidden">
                <img 
                  src="/images/burgers/cheese-bacon.jpg" 
                  alt="Nossos Hambúrgueres" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="rounded-lg overflow-hidden">
                <img 
                  src="/images/sides/fries.jpg" 
                  alt="Acompanhamentos" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="rounded-lg overflow-hidden">
                <img 
                  src="/images/drinks/milkshake.jpg" 
                  alt="Bebidas" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="rounded-lg overflow-hidden">
                <img 
                  src="/images/desserts/brownie.jpg" 
                  alt="Sobremesas" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Reviews Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-bold">O Que Nossos Clientes Dizem</h2>
            <Link 
              to="/reviews" 
              className="flex items-center text-primary hover:text-primary/80 font-medium"
            >
              Ver Todas as Avaliações
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {topReviews.map(review => (
              <ReviewCard key={review.id} review={review} />
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Venha Experimentar Nossos Hambúrgueres</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Estamos esperando por você para proporcionar uma experiência gastronômica inesquecível. 
            Venha conhecer a BurgerBliss e descubra por que somos a hamburgueria favorita da cidade.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-background text-foreground hover:bg-background/90"
              asChild
            >
              <Link to="/menu">Ver Cardápio</Link>
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-background text-background hover:bg-background/10"
              asChild
            >
              <Link to="/contact">Como Chegar</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;

