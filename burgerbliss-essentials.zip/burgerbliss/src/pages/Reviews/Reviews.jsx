import { useState, useEffect } from 'react';
import ReviewCard from '@/components/ReviewCard/ReviewCard';
import ReviewFilter from '@/components/ReviewFilter/ReviewFilter';
import AIAnalysisIntegration from '@/components/AIAnalysis/AIAnalysisIntegration';
import reviews from '@/data/reviews';
import products from '@/data/products';
import { getAvatarUrl } from '@/utils/avatarGenerator';

const Reviews = () => {
  const [filteredReviews, setFilteredReviews] = useState([]);
  const [filters, setFilters] = useState({
    rating: 0,
    product: '',
    sortBy: 'recent'
  });
  const [showAnalysis, setShowAnalysis] = useState(false);
  
  // Processar os reviews para garantir que tenham URLs de avatar
  const processedReviews = reviews.map(review => ({
    ...review,
    customerImage: getAvatarUrl(review.customerName, review.customerImage)
  }));
  
  // Aplicar filtros aos reviews
  useEffect(() => {
    let result = [...processedReviews];
    
    // Filtrar por avaliação
    if (filters.rating > 0) {
      result = result.filter(review => review.rating === filters.rating);
    }
    
    // Filtrar por produto
    if (filters.product) {
      result = result.filter(review => review.productId === filters.product);
    }
    
    // Ordenar reviews
    switch (filters.sortBy) {
      case 'recent':
        result.sort((a, b) => new Date(b.date) - new Date(a.date));
        break;
      case 'oldest':
        result.sort((a, b) => new Date(a.date) - new Date(b.date));
        break;
      case 'highest':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'lowest':
        result.sort((a, b) => a.rating - b.rating);
        break;
      default:
        result.sort((a, b) => new Date(b.date) - new Date(a.date));
    }
    
    setFilteredReviews(result);
  }, [filters]);
  
  // Manipular mudanças de filtro
  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
  };
  
  // Calcular estatísticas gerais
  const totalReviews = processedReviews.length;
  const averageRating = (
    processedReviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews
  ).toFixed(1);
  
  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Avaliações dos Clientes</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Veja o que nossos clientes estão dizendo sobre a BurgerBliss. 
            Sua opinião é muito importante para continuarmos melhorando!
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center items-center gap-8 mt-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary">{averageRating}</div>
              <div className="text-sm text-muted-foreground">Avaliação média</div>
            </div>
            
            <div className="text-center">
              <div className="text-4xl font-bold text-primary">{totalReviews}</div>
              <div className="text-sm text-muted-foreground">Total de avaliações</div>
            </div>
            
            <div className="text-center">
              <div className="text-4xl font-bold text-primary">
                {processedReviews.filter(r => r.rating >= 4).length}
              </div>
              <div className="text-sm text-muted-foreground">Avaliações positivas</div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Coluna de filtros e análise em dispositivos grandes */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <ReviewFilter 
                onFilterChange={handleFilterChange} 
                products={products}
              />
              
              <div className="mt-8">
                <button
                  onClick={() => setShowAnalysis(!showAnalysis)}
                  className="w-full bg-primary text-white py-3 px-4 rounded-md hover:bg-primary/90 transition-colors"
                >
                  {showAnalysis ? 'Ocultar Análise de IA' : 'Mostrar Análise de IA'}
                </button>
              </div>
            </div>
          </div>
          
          {/* Coluna de avaliações */}
          <div className="lg:col-span-2">
            {showAnalysis && (
              <div className="mb-8">
                <AIAnalysisIntegration 
                  reviews={processedReviews}
                />
              </div>
            )}
            
            <div className="space-y-6">
              {filteredReviews.length > 0 ? (
                filteredReviews.map(review => (
                  <ReviewCard key={review.id} review={review} />
                ))
              ) : (
                <div className="text-center py-12 bg-muted/30 rounded-lg">
                  <p className="text-lg text-muted-foreground">
                    Nenhuma avaliação encontrada com os filtros selecionados.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reviews;

