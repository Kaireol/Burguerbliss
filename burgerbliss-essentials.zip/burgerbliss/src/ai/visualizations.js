/**
 * Módulo de Visualizações
 * 
 * Este módulo contém funções para gerar dados para visualizações
 * a partir das análises de avaliações.
 */

import { analyzeReviewsSentiment } from './sentimentAnalysis.js';
import { analyzeTopics, generateReviewSummary } from './reviewSummary.js';

/**
 * Gera dados para gráfico de pizza de sentimento
 * @param {Object} sentimentAnalysis - Resultado da análise de sentimento
 * @returns {Array} - Dados formatados para gráfico de pizza
 */
export const generateSentimentPieData = (sentimentAnalysis) => {
  return [
    {
      name: 'Positivo',
      value: sentimentAnalysis.percentages.positive,
      color: '#2B9348' // Verde
    },
    {
      name: 'Neutro',
      value: sentimentAnalysis.percentages.neutral,
      color: '#FFB627' // Amarelo
    },
    {
      name: 'Negativo',
      value: sentimentAnalysis.percentages.negative,
      color: '#D62300' // Vermelho
    }
  ];
};

/**
 * Gera dados para gráfico de barras de distribuição de avaliações
 * @param {Array} ratingDistribution - Distribuição de avaliações por estrelas
 * @returns {Array} - Dados formatados para gráfico de barras
 */
export const generateRatingBarData = (ratingDistribution) => {
  return ratingDistribution.map(item => ({
    name: `${item.rating} estrelas`,
    count: item.count,
    color: getRatingColor(item.rating)
  }));
};

/**
 * Gera dados para gráfico de tópicos mencionados
 * @param {Object} topicAnalysis - Resultado da análise de tópicos
 * @param {number} limit - Limite de tópicos a serem incluídos
 * @returns {Array} - Dados formatados para gráfico de tópicos
 */
export const generateTopicsData = (topicAnalysis, limit = 5) => {
  return topicAnalysis.topics
    .slice(0, limit)
    .map(topic => ({
      topic: formatTopicName(topic.topic),
      count: topic.total,
      sentiment: topic.predominantSentiment
    }));
};

/**
 * Gera dados para resumo visual da análise
 * @param {Object} summary - Resumo gerado das avaliações
 * @returns {Object} - Dados formatados para visualizações
 */
export const generateVisualizationData = (summary) => {
  return {
    sentimentPieData: generateSentimentPieData(summary.sentimentAnalysis),
    ratingBarData: generateRatingBarData(summary.ratingDistribution),
    topicsData: generateTopicsData(summary.topicAnalysis, 5),
    positiveTopics: summary.positiveTopics.map(formatTopicName),
    neutralTopics: summary.neutralTopics.map(formatTopicName),
    negativeTopics: summary.negativeTopics.map(formatTopicName),
    summary: summary.summary
  };
};

/**
 * Analisa avaliações e gera dados para visualizações
 * @param {Array} reviews - Array de objetos de avaliação
 * @returns {Object} - Dados formatados para visualizações
 */
export const analyzeReviewsForVisualization = (reviews) => {
  const summary = generateReviewSummary(reviews);
  return generateVisualizationData(summary);
};

// Funções auxiliares

/**
 * Retorna uma cor com base na avaliação (1-5 estrelas)
 * @param {number} rating - Avaliação (1-5)
 * @returns {string} - Código de cor hexadecimal
 */
function getRatingColor(rating) {
  switch (rating) {
    case 5: return '#2B9348'; // Verde escuro
    case 4: return '#65B75E'; // Verde claro
    case 3: return '#FFB627'; // Amarelo
    case 2: return '#FF8A5B'; // Laranja
    case 1: return '#D62300'; // Vermelho
    default: return '#CCCCCC'; // Cinza
  }
}

/**
 * Formata o nome do tópico para exibição
 * @param {string} topic - Nome do tópico
 * @returns {string} - Nome formatado
 */
function formatTopicName(topic) {
  const topicNames = {
    sabor: 'Sabor',
    qualidade: 'Qualidade',
    atendimento: 'Atendimento',
    ambiente: 'Ambiente',
    preço: 'Preço',
    porção: 'Porção',
    tempo: 'Tempo de espera',
    apresentação: 'Apresentação',
    temperatura: 'Temperatura',
    textura: 'Textura'
  };
  
  return topicNames[topic] || topic.charAt(0).toUpperCase() + topic.slice(1);
}

export default {
  generateSentimentPieData,
  generateRatingBarData,
  generateTopicsData,
  generateVisualizationData,
  analyzeReviewsForVisualization
};

