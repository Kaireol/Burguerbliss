/**
 * Módulo principal de IA para análise de feedback
 * 
 * Este módulo integra todos os componentes de análise de sentimento,
 * resumo de avaliações e visualizações em uma única interface.
 */

import * as sentimentAnalysis from './sentimentAnalysis.js';
import * as reviewSummary from './reviewSummary.js';
import * as visualizations from './visualizations.js';

/**
 * Analisa um conjunto de avaliações e retorna resultados completos
 * @param {Array} reviews - Array de objetos de avaliação
 * @returns {Object} - Resultados completos da análise
 */
export const analyzeReviews = (reviews) => {
  if (!reviews || reviews.length === 0) {
    return {
      success: false,
      message: "Não há avaliações para analisar",
      data: null
    };
  }
  
  try {
    // Análise de sentimento
    const sentimentResults = sentimentAnalysis.analyzeReviewsSentiment(reviews);
    
    // Resumo das avaliações
    const summaryResults = reviewSummary.generateReviewSummary(reviews);
    
    // Dados para visualizações
    const visualizationData = visualizations.generateVisualizationData(summaryResults);
    
    return {
      success: true,
      message: "Análise concluída com sucesso",
      data: {
        sentiment: sentimentResults,
        summary: summaryResults,
        visualizations: visualizationData
      }
    };
  } catch (error) {
    console.error("Erro ao analisar avaliações:", error);
    return {
      success: false,
      message: "Ocorreu um erro ao analisar as avaliações",
      error: error.message
    };
  }
};

/**
 * Analisa uma única avaliação
 * @param {Object} review - Objeto de avaliação
 * @returns {Object} - Resultados da análise
 */
export const analyzeReview = (review) => {
  if (!review) {
    return {
      success: false,
      message: "Avaliação inválida",
      data: null
    };
  }
  
  try {
    // Análise de sentimento
    const sentimentResult = sentimentAnalysis.analyzeReviewSentiment(review);
    
    // Extração de tópicos
    const topics = reviewSummary.extractTopics(review.comment);
    
    return {
      success: true,
      message: "Análise concluída com sucesso",
      data: {
        sentiment: sentimentResult,
        topics
      }
    };
  } catch (error) {
    console.error("Erro ao analisar avaliação:", error);
    return {
      success: false,
      message: "Ocorreu um erro ao analisar a avaliação",
      error: error.message
    };
  }
};

/**
 * Gera um relatório completo de análise de avaliações
 * @param {Array} reviews - Array de objetos de avaliação
 * @returns {Object} - Relatório completo
 */
export const generateReviewReport = (reviews) => {
  const analysisResults = analyzeReviews(reviews);
  
  if (!analysisResults.success) {
    return analysisResults;
  }
  
  // Estatísticas gerais
  const totalReviews = reviews.length;
  const averageRating = (
    reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews
  ).toFixed(1);
  
  // Produtos mais avaliados
  const productCounts = {};
  reviews.forEach(review => {
    if (!productCounts[review.productId]) {
      productCounts[review.productId] = {
        id: review.productId,
        name: review.productName,
        count: 0,
        ratings: []
      };
    }
    
    productCounts[review.productId].count += 1;
    productCounts[review.productId].ratings.push(review.rating);
  });
  
  // Calcula média de avaliação por produto
  const productsWithStats = Object.values(productCounts).map(product => ({
    ...product,
    averageRating: (
      product.ratings.reduce((sum, rating) => sum + rating, 0) / product.count
    ).toFixed(1)
  }));
  
  // Ordena produtos por número de avaliações
  const topProducts = productsWithStats
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);
  
  // Tendência temporal (últimos 3 meses vs. anteriores)
  const now = new Date();
  const threeMonthsAgo = new Date();
  threeMonthsAgo.setMonth(now.getMonth() - 3);
  
  const recentReviews = reviews.filter(review => new Date(review.date) >= threeMonthsAgo);
  const olderReviews = reviews.filter(review => new Date(review.date) < threeMonthsAgo);
  
  const recentAvgRating = recentReviews.length > 0 
    ? (recentReviews.reduce((sum, review) => sum + review.rating, 0) / recentReviews.length).toFixed(1)
    : 0;
    
  const olderAvgRating = olderReviews.length > 0
    ? (olderReviews.reduce((sum, review) => sum + review.rating, 0) / olderReviews.length).toFixed(1)
    : 0;
  
  const ratingTrend = recentAvgRating - olderAvgRating;
  
  return {
    success: true,
    message: "Relatório gerado com sucesso",
    data: {
      ...analysisResults.data,
      statistics: {
        totalReviews,
        averageRating,
        topProducts,
        trend: {
          recentAvgRating,
          olderAvgRating,
          difference: ratingTrend.toFixed(1),
          improving: ratingTrend >= 0
        }
      }
    }
  };
};

export default {
  analyzeReviews,
  analyzeReview,
  generateReviewReport,
  sentimentAnalysis,
  reviewSummary,
  visualizations
};

