/**
 * Módulo de Resumo de Avaliações
 * 
 * Este módulo contém funções para resumir avaliações de clientes,
 * extrair tópicos mencionados e gerar insights a partir dos dados.
 */

import { analyzeReviewsSentiment } from './sentimentAnalysis.js';

// Lista de tópicos comuns em avaliações de restaurantes
const commonTopics = {
  sabor: ['sabor', 'saboroso', 'saborosa', 'gosto', 'delicioso', 'deliciosa', 'tempero'],
  qualidade: ['qualidade', 'fresco', 'frescos', 'frescas', 'ingredientes', 'artesanal'],
  atendimento: ['atendimento', 'atencioso', 'atenciosa', 'garçom', 'garçonete', 'equipe', 'staff', 'funcionários', 'simpático', 'simpática', 'educado', 'educada'],
  ambiente: ['ambiente', 'local', 'decoração', 'música', 'iluminação', 'aconchegante', 'confortável', 'agradável'],
  preço: ['preço', 'caro', 'cara', 'barato', 'barata', 'valor', 'custo-benefício', 'custo', 'benefício', 'justo', 'justa'],
  porção: ['porção', 'quantidade', 'tamanho', 'grande', 'pequeno', 'pequena', 'generoso', 'generosa'],
  tempo: ['tempo', 'espera', 'demora', 'demorado', 'demorada', 'rápido', 'rápida', 'ágil', 'agilidade'],
  apresentação: ['apresentação', 'visual', 'bonito', 'bonita', 'aparência', 'aspecto'],
  temperatura: ['temperatura', 'quente', 'frio', 'fria', 'morno', 'morna'],
  textura: ['textura', 'crocante', 'macio', 'macia', 'suculento', 'suculenta', 'seco', 'seca', 'duro', 'dura']
};

/**
 * Extrai tópicos mencionados em uma avaliação
 * @param {string} text - Texto da avaliação
 * @returns {Array} - Array de tópicos encontrados
 */
export const extractTopics = (text) => {
  if (!text) return [];
  
  const lowerText = text.toLowerCase();
  const foundTopics = [];
  
  // Verifica cada tópico
  Object.entries(commonTopics).forEach(([topic, keywords]) => {
    // Verifica se alguma palavra-chave do tópico está presente no texto
    const found = keywords.some(keyword => {
      const regex = new RegExp(`\\b${keyword}\\b`, 'i');
      return regex.test(lowerText);
    });
    
    if (found && !foundTopics.includes(topic)) {
      foundTopics.push(topic);
    }
  });
  
  return foundTopics;
};

/**
 * Analisa os tópicos mencionados em um conjunto de avaliações
 * @param {Array} reviews - Array de objetos de avaliação
 * @returns {Object} - Objeto com contagem de tópicos por sentimento
 */
export const analyzeTopics = (reviews) => {
  if (!reviews || reviews.length === 0) {
    return { topics: [] };
  }
  
  // Analisa o sentimento das avaliações
  const sentimentAnalysis = analyzeReviewsSentiment(reviews);
  
  // Extrai tópicos de cada avaliação
  const reviewsWithTopics = sentimentAnalysis.analyzedReviews.map(review => {
    const extractedTopics = extractTopics(review.comment);
    return {
      ...review,
      extractedTopics
    };
  });
  
  // Conta menções de cada tópico por sentimento
  const topicCounts = {};
  
  reviewsWithTopics.forEach(review => {
    const sentiment = review.analysis.finalSentiment;
    
    review.extractedTopics.forEach(topic => {
      if (!topicCounts[topic]) {
        topicCounts[topic] = {
          topic,
          total: 0,
          positive: 0,
          neutral: 0,
          negative: 0
        };
      }
      
      topicCounts[topic].total += 1;
      topicCounts[topic][sentiment] += 1;
    });
  });
  
  // Converte para array e calcula o sentimento predominante
  const topicsArray = Object.values(topicCounts).map(item => {
    let predominantSentiment = 'neutral';
    
    if (item.positive > item.neutral && item.positive > item.negative) {
      predominantSentiment = 'positive';
    } else if (item.negative > item.neutral && item.negative > item.positive) {
      predominantSentiment = 'negative';
    }
    
    return {
      ...item,
      predominantSentiment
    };
  });
  
  // Ordena por número total de menções
  const sortedTopics = topicsArray.sort((a, b) => b.total - a.total);
  
  return {
    topics: sortedTopics,
    reviewsWithTopics
  };
};

/**
 * Gera um resumo das avaliações
 * @param {Array} reviews - Array de objetos de avaliação
 * @returns {Object} - Objeto com resumo das avaliações
 */
export const generateReviewSummary = (reviews) => {
  if (!reviews || reviews.length === 0) {
    return {
      sentimentAnalysis: {
        positive: 0,
        neutral: 0,
        negative: 0,
        total: 0,
        percentages: {
          positive: 0,
          neutral: 0,
          negative: 0
        }
      },
      topicAnalysis: {
        topics: []
      },
      ratingDistribution: [],
      summary: "Não há avaliações suficientes para gerar um resumo."
    };
  }
  
  // Análise de sentimento
  const sentimentAnalysis = analyzeReviewsSentiment(reviews);
  
  // Análise de tópicos
  const topicAnalysis = analyzeTopics(reviews);
  
  // Distribuição de avaliações por estrelas
  const ratingDistribution = [5, 4, 3, 2, 1].map(rating => {
    const count = reviews.filter(review => review.rating === rating).length;
    const percentage = Math.round((count / reviews.length) * 100);
    
    return {
      rating,
      count,
      percentage
    };
  });
  
  // Pontos positivos (tópicos com sentimento predominantemente positivo)
  const positiveTopics = topicAnalysis.topics
    .filter(topic => topic.predominantSentiment === 'positive')
    .slice(0, 3)
    .map(topic => topic.topic);
  
  // Pontos negativos (tópicos com sentimento predominantemente negativo)
  const negativeTopics = topicAnalysis.topics
    .filter(topic => topic.predominantSentiment === 'negative')
    .slice(0, 3)
    .map(topic => topic.topic);
  
  // Pontos neutros (tópicos com sentimento predominantemente neutro)
  const neutralTopics = topicAnalysis.topics
    .filter(topic => topic.predominantSentiment === 'neutral')
    .slice(0, 3)
    .map(topic => topic.topic);
  
  // Gera texto de resumo
  let summaryText = "";
  
  // Sentimento geral
  if (sentimentAnalysis.percentages.positive > 70) {
    summaryText += "A maioria dos clientes está muito satisfeita com a BurgerBliss. ";
  } else if (sentimentAnalysis.percentages.positive > 50) {
    summaryText += "Os clientes estão geralmente satisfeitos com a BurgerBliss, embora haja algumas críticas. ";
  } else if (sentimentAnalysis.percentages.negative > 50) {
    summaryText += "Há um número significativo de clientes insatisfeitos com a BurgerBliss. ";
  } else {
    summaryText += "As opiniões sobre a BurgerBliss são mistas. ";
  }
  
  // Pontos positivos
  if (positiveTopics.length > 0) {
    summaryText += "Os principais pontos elogiados são: ";
    summaryText += positiveTopics.map(topic => {
      switch(topic) {
        case 'sabor': return "o sabor dos alimentos";
        case 'qualidade': return "a qualidade dos ingredientes";
        case 'atendimento': return "o atendimento";
        case 'ambiente': return "o ambiente";
        case 'preço': return "o preço justo";
        case 'porção': return "o tamanho das porções";
        case 'tempo': return "a rapidez no atendimento";
        case 'apresentação': return "a apresentação dos pratos";
        case 'temperatura': return "a temperatura adequada dos alimentos";
        case 'textura': return "a textura dos alimentos";
        default: return topic;
      }
    }).join(", ") + ". ";
  }
  
  // Pontos negativos
  if (negativeTopics.length > 0) {
    summaryText += "Os principais pontos criticados são: ";
    summaryText += negativeTopics.map(topic => {
      switch(topic) {
        case 'sabor': return "o sabor dos alimentos";
        case 'qualidade': return "a qualidade dos ingredientes";
        case 'atendimento': return "o atendimento";
        case 'ambiente': return "o ambiente";
        case 'preço': return "o preço elevado";
        case 'porção': return "o tamanho das porções";
        case 'tempo': return "o tempo de espera";
        case 'apresentação': return "a apresentação dos pratos";
        case 'temperatura': return "a temperatura inadequada dos alimentos";
        case 'textura': return "a textura dos alimentos";
        default: return topic;
      }
    }).join(", ") + ". ";
  }
  
  // Recomendações
  if (negativeTopics.length > 0) {
    summaryText += "Recomenda-se focar em melhorias nos seguintes aspectos: ";
    summaryText += negativeTopics.map(topic => {
      switch(topic) {
        case 'sabor': return "aprimorar as receitas";
        case 'qualidade': return "melhorar a seleção de ingredientes";
        case 'atendimento': return "treinar a equipe para um atendimento mais eficiente";
        case 'ambiente': return "renovar o ambiente";
        case 'preço': return "revisar a política de preços";
        case 'porção': return "ajustar o tamanho das porções";
        case 'tempo': return "otimizar o tempo de preparo";
        case 'apresentação': return "melhorar a apresentação visual dos pratos";
        case 'temperatura': return "garantir que os alimentos sejam servidos na temperatura adequada";
        case 'textura': return "ajustar o preparo para melhorar a textura dos alimentos";
        default: return `melhorar ${topic}`;
      }
    }).join(", ") + ". ";
  } else {
    summaryText += "Recomenda-se manter o padrão de qualidade atual e continuar inovando para manter os clientes satisfeitos.";
  }
  
  return {
    sentimentAnalysis,
    topicAnalysis,
    ratingDistribution,
    positiveTopics,
    neutralTopics,
    negativeTopics,
    summary: summaryText
  };
};

export default {
  extractTopics,
  analyzeTopics,
  generateReviewSummary
};

