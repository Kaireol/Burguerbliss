/**
 * Script de teste para o agente de IA
 * 
 * Este script testa as funcionalidades do agente de IA para análise de feedback
 * usando as avaliações fictícias do website.
 */

import reviews from '../data/reviews.js';
import { analyzeReviews, analyzeReview, generateReviewReport } from './index.js';

// Função para imprimir resultados formatados
const printResults = (title, data) => {
  console.log('\n' + '='.repeat(50));
  console.log(`${title}:`);
  console.log('='.repeat(50));
  console.log(JSON.stringify(data, null, 2));
};

// Teste 1: Analisar uma única avaliação
const testSingleReview = () => {
  console.log('\n\nTESTE 1: Análise de uma única avaliação');
  
  // Seleciona uma avaliação positiva
  const positiveReview = reviews.find(review => review.rating === 5);
  const positiveResult = analyzeReview(positiveReview);
  printResults('Análise de avaliação positiva', positiveResult);
  
  // Seleciona uma avaliação neutra
  const neutralReview = reviews.find(review => review.rating === 3);
  const neutralResult = analyzeReview(neutralReview);
  printResults('Análise de avaliação neutra', neutralResult);
  
  // Seleciona uma avaliação negativa
  const negativeReview = reviews.find(review => review.rating === 1);
  const negativeResult = analyzeReview(negativeReview);
  printResults('Análise de avaliação negativa', negativeResult);
};

// Teste 2: Analisar todas as avaliações
const testAllReviews = () => {
  console.log('\n\nTESTE 2: Análise de todas as avaliações');
  
  const result = analyzeReviews(reviews);
  
  // Exibe apenas estatísticas resumidas para não sobrecarregar o console
  const summary = {
    success: result.success,
    message: result.message,
    sentimentCounts: {
      positive: result.data?.sentiment.positive || 0,
      neutral: result.data?.sentiment.neutral || 0,
      negative: result.data?.sentiment.negative || 0,
      total: result.data?.sentiment.total || 0
    },
    percentages: result.data?.sentiment.percentages || {},
    topTopics: result.data?.summary.topicAnalysis.topics.slice(0, 5) || []
  };
  
  printResults('Resumo da análise de todas as avaliações', summary);
};

// Teste 3: Gerar relatório completo
const testFullReport = () => {
  console.log('\n\nTESTE 3: Geração de relatório completo');
  
  const report = generateReviewReport(reviews);
  
  // Exibe apenas as partes mais importantes do relatório
  const reportSummary = {
    success: report.success,
    message: report.message,
    statistics: report.data?.statistics || {},
    sentimentPercentages: report.data?.sentiment.percentages || {},
    topTopics: report.data?.summary.topicAnalysis.topics.slice(0, 5) || [],
    summary: report.data?.visualizations.summary || ''
  };
  
  printResults('Resumo do relatório completo', reportSummary);
};

// Executa os testes
const runTests = () => {
  console.log('Iniciando testes do agente de IA...');
  console.log(`Total de avaliações: ${reviews.length}`);
  
  testSingleReview();
  testAllReviews();
  testFullReport();
  
  console.log('\n\nTestes concluídos!');
};

// Executa os testes
runTests();

