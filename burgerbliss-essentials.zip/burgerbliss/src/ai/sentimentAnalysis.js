/**
 * Módulo de Análise de Sentimento
 * 
 * Este módulo contém funções para analisar o sentimento de avaliações de clientes.
 * Utiliza uma abordagem baseada em dicionário de palavras positivas e negativas,
 * bem como análise de pontuação (rating) para determinar o sentimento geral.
 */

// Dicionário de palavras positivas em português
const positiveWords = [
  'bom', 'ótimo', 'excelente', 'maravilhoso', 'incrível', 'delicioso', 'saboroso',
  'perfeito', 'adorei', 'gostei', 'recomendo', 'fantástico', 'sensacional', 'divino',
  'fresco', 'qualidade', 'atencioso', 'rápido', 'eficiente', 'simpático', 'aconchegante',
  'agradável', 'satisfeito', 'melhor', 'suculento', 'crocante', 'macio', 'saborosa',
  'deliciosa', 'excelentes', 'ótimos', 'maravilhosa', 'frescos', 'frescas', 'amei',
  'voltarei', 'recomendarei', 'surpreendente', 'surpreendeu', 'superou', 'expectativas',
  'vale', 'pena', 'justo', 'acessível', 'generoso', 'generosa', 'bem', 'servido'
];

// Dicionário de palavras negativas em português
const negativeWords = [
  'ruim', 'péssimo', 'horrível', 'terrível', 'decepcionante', 'decepção', 'insatisfeito',
  'insatisfação', 'demorado', 'demorou', 'espera', 'caro', 'cara', 'não', 'nunca',
  'problema', 'problemas', 'queixa', 'reclamação', 'desapontado', 'desapontei', 'mal',
  'pior', 'frio', 'fria', 'queimado', 'queimada', 'seco', 'seca', 'duro', 'dura',
  'oleoso', 'oleosa', 'gorduroso', 'gordurosa', 'salgado', 'salgada', 'sem', 'sabor',
  'insosso', 'insossa', 'cru', 'crua', 'sujo', 'suja', 'não recomendo', 'não voltarei',
  'desagradável', 'grosseiro', 'grosseira', 'lento', 'lenta', 'erro', 'errado'
];

/**
 * Analisa o sentimento de um texto com base em palavras positivas e negativas
 * @param {string} text - O texto a ser analisado
 * @returns {Object} - Objeto com pontuação de sentimento e classificação
 */
export const analyzeSentiment = (text) => {
  if (!text) return { score: 0, sentiment: 'neutral' };
  
  const lowerText = text.toLowerCase();
  let positiveScore = 0;
  let negativeScore = 0;
  
  // Conta palavras positivas
  positiveWords.forEach(word => {
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    const matches = lowerText.match(regex);
    if (matches) {
      positiveScore += matches.length;
    }
  });
  
  // Conta palavras negativas
  negativeWords.forEach(word => {
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    const matches = lowerText.match(regex);
    if (matches) {
      negativeScore += matches.length;
    }
  });
  
  // Calcula pontuação final
  const score = positiveScore - negativeScore;
  
  // Determina o sentimento
  let sentiment;
  if (score > 0) {
    sentiment = 'positive';
  } else if (score < 0) {
    sentiment = 'negative';
  } else {
    sentiment = 'neutral';
  }
  
  return {
    score,
    positiveScore,
    negativeScore,
    sentiment
  };
};

/**
 * Analisa o sentimento de uma avaliação com base no texto e na pontuação
 * @param {Object} review - Objeto de avaliação com texto e pontuação
 * @returns {Object} - Objeto com análise de sentimento
 */
export const analyzeReviewSentiment = (review) => {
  const textAnalysis = analyzeSentiment(review.comment);
  
  // Incorpora a pontuação (rating) na análise
  let ratingWeight = 0;
  
  if (review.rating >= 4) {
    ratingWeight = 2; // Pontuação alta (4-5) tem peso positivo
  } else if (review.rating <= 2) {
    ratingWeight = -2; // Pontuação baixa (1-2) tem peso negativo
  }
  
  // Ajusta a pontuação final com base no rating
  const finalScore = textAnalysis.score + ratingWeight;
  
  // Determina o sentimento final
  let finalSentiment;
  if (finalScore > 0) {
    finalSentiment = 'positive';
  } else if (finalScore < 0) {
    finalSentiment = 'negative';
  } else {
    finalSentiment = 'neutral';
  }
  
  return {
    ...textAnalysis,
    finalScore,
    finalSentiment,
    rating: review.rating
  };
};

/**
 * Analisa o sentimento de um conjunto de avaliações
 * @param {Array} reviews - Array de objetos de avaliação
 * @returns {Object} - Objeto com estatísticas de sentimento
 */
export const analyzeReviewsSentiment = (reviews) => {
  if (!reviews || reviews.length === 0) {
    return {
      positive: 0,
      neutral: 0,
      negative: 0,
      total: 0,
      percentages: {
        positive: 0,
        neutral: 0,
        negative: 0
      }
    };
  }
  
  // Analisa cada avaliação
  const analyzedReviews = reviews.map(review => ({
    ...review,
    analysis: analyzeReviewSentiment(review)
  }));
  
  // Conta os sentimentos
  const sentimentCounts = analyzedReviews.reduce((counts, review) => {
    const sentiment = review.analysis.finalSentiment;
    counts[sentiment] += 1;
    return counts;
  }, { positive: 0, neutral: 0, negative: 0 });
  
  // Calcula percentuais
  const total = reviews.length;
  const percentages = {
    positive: Math.round((sentimentCounts.positive / total) * 100),
    neutral: Math.round((sentimentCounts.neutral / total) * 100),
    negative: Math.round((sentimentCounts.negative / total) * 100)
  };
  
  return {
    ...sentimentCounts,
    total,
    percentages,
    analyzedReviews
  };
};

export default {
  analyzeSentiment,
  analyzeReviewSentiment,
  analyzeReviewsSentiment
};

