# Guia do Agente de IA para Análise de Feedback

Este documento fornece informações detalhadas sobre o agente de IA para análise de feedback implementado no projeto BurgerBliss.

## Visão Geral

O agente de IA é projetado para analisar avaliações de clientes, identificar sentimentos, extrair tópicos mencionados e gerar resumos e visualizações dos dados. Ele é composto por três módulos principais:

1. **Análise de Sentimento**: Identifica se as avaliações são positivas, neutras ou negativas.
2. **Resumo de Avaliações**: Extrai tópicos e gera resumos das avaliações.
3. **Visualizações**: Gera dados formatados para visualizações.

## Arquitetura

```
src/ai/
├── index.js             # Ponto de entrada e API unificada
├── sentimentAnalysis.js # Análise de sentimento
├── reviewSummary.js     # Extração de tópicos e resumo
├── visualizations.js    # Geração de visualizações
└── test.js              # Testes do agente de IA
```

## Módulos

### 1. Análise de Sentimento (`sentimentAnalysis.js`)

Este módulo é responsável por analisar o sentimento de avaliações com base em palavras-chave e pontuação.

#### Principais funções:

- **analyzeSentiment(text)**: Analisa o sentimento de um texto com base em palavras positivas e negativas.
- **analyzeReviewSentiment(review)**: Analisa o sentimento de uma avaliação com base no texto e na pontuação.
- **analyzeReviewsSentiment(reviews)**: Analisa o sentimento de um conjunto de avaliações.

#### Exemplo de uso:

```javascript
import { analyzeReviewSentiment } from './ai/sentimentAnalysis.js';

const review = {
  comment: "O hambúrguer estava delicioso e o atendimento foi excelente!",
  rating: 5
};

const result = analyzeReviewSentiment(review);
console.log(result);
```

#### Resultado:

```javascript
{
  score: 2,              // Pontuação baseada em palavras-chave (positivas - negativas)
  positiveScore: 2,      // Número de palavras positivas encontradas
  negativeScore: 0,      // Número de palavras negativas encontradas
  sentiment: "positive", // Sentimento baseado apenas no texto
  finalScore: 4,         // Pontuação final (texto + rating)
  finalSentiment: "positive", // Sentimento final
  rating: 5              // Rating original
}
```

### 2. Resumo de Avaliações (`reviewSummary.js`)

Este módulo é responsável por extrair tópicos mencionados nas avaliações e gerar resumos.

#### Principais funções:

- **extractTopics(text)**: Extrai tópicos mencionados em um texto.
- **analyzeTopics(reviews)**: Analisa os tópicos mencionados em um conjunto de avaliações.
- **generateReviewSummary(reviews)**: Gera um resumo completo das avaliações.

#### Exemplo de uso:

```javascript
import { extractTopics, generateReviewSummary } from './ai/reviewSummary.js';

// Extrair tópicos de um texto
const text = "O sabor do hambúrguer é incrível e o atendimento foi rápido.";
const topics = extractTopics(text);
console.log(topics); // ["sabor", "atendimento", "tempo"]

// Gerar resumo de avaliações
const summary = generateReviewSummary(reviews);
console.log(summary.summary); // Texto de resumo
```

### 3. Visualizações (`visualizations.js`)

Este módulo é responsável por gerar dados formatados para visualizações.

#### Principais funções:

- **generateSentimentPieData(sentimentAnalysis)**: Gera dados para gráfico de pizza de sentimento.
- **generateRatingBarData(ratingDistribution)**: Gera dados para gráfico de barras de distribuição de avaliações.
- **generateTopicsData(topicAnalysis, limit)**: Gera dados para gráfico de tópicos mencionados.
- **generateVisualizationData(summary)**: Gera dados completos para visualizações.

#### Exemplo de uso:

```javascript
import { generateVisualizationData } from './ai/visualizations.js';
import { generateReviewSummary } from './ai/reviewSummary.js';

const summary = generateReviewSummary(reviews);
const visualizationData = generateVisualizationData(summary);

console.log(visualizationData.sentimentPieData); // Dados para gráfico de pizza
console.log(visualizationData.ratingBarData);    // Dados para gráfico de barras
console.log(visualizationData.topicsData);       // Dados para gráfico de tópicos
```

## API Unificada (`index.js`)

O módulo `index.js` integra todos os módulos e fornece uma API unificada para análise de avaliações.

### Principais funções:

- **analyzeReview(review)**: Analisa uma única avaliação.
- **analyzeReviews(reviews)**: Analisa um conjunto de avaliações.
- **generateReviewReport(reviews)**: Gera um relatório completo de análise de avaliações.

### Exemplo de uso:

```javascript
import { analyzeReviews, generateReviewReport } from './ai';

// Analisar avaliações
const analysisResults = analyzeReviews(reviews);
console.log(analysisResults.data.sentiment); // Resultados da análise de sentimento

// Gerar relatório completo
const report = generateReviewReport(reviews);
console.log(report.data.statistics);        // Estatísticas gerais
console.log(report.data.visualizations);    // Dados para visualizações
```

## Estrutura de Dados

### Avaliação (`review`)

```javascript
{
  id: "review-1",                      // ID único da avaliação
  customerName: "Nome do Cliente",     // Nome do cliente
  customerImage: "/path/to/image.jpg", // Imagem do cliente
  date: "2025-05-28",                  // Data da avaliação
  rating: 5,                           // Pontuação (1-5)
  productId: "product-1",              // ID do produto avaliado
  productName: "Nome do Produto",      // Nome do produto avaliado
  comment: "Texto da avaliação..."     // Texto da avaliação
}
```

### Resultado da Análise de Sentimento

```javascript
{
  positive: 23,        // Número de avaliações positivas
  neutral: 5,          // Número de avaliações neutras
  negative: 2,         // Número de avaliações negativas
  total: 30,           // Total de avaliações
  percentages: {
    positive: 77,      // Percentual de avaliações positivas
    neutral: 17,       // Percentual de avaliações neutras
    negative: 6        // Percentual de avaliações negativas
  }
}
```

### Resultado da Análise de Tópicos

```javascript
{
  topics: [
    {
      topic: "sabor",               // Nome do tópico
      total: 17,                    // Total de menções
      positive: 12,                 // Menções positivas
      neutral: 3,                   // Menções neutras
      negative: 2,                  // Menções negativas
      predominantSentiment: "positive" // Sentimento predominante
    },
    // ... outros tópicos
  ]
}
```

### Relatório Completo

```javascript
{
  success: true,
  message: "Relatório gerado com sucesso",
  data: {
    sentiment: { /* Análise de sentimento */ },
    summary: { 
      sentimentAnalysis: { /* Análise de sentimento */ },
      topicAnalysis: { /* Análise de tópicos */ },
      ratingDistribution: [ /* Distribuição de avaliações */ ],
      positiveTopics: [ /* Tópicos positivos */ ],
      neutralTopics: [ /* Tópicos neutros */ ],
      negativeTopics: [ /* Tópicos negativos */ ],
      summary: "Texto de resumo..."
    },
    visualizations: { /* Dados para visualizações */ },
    statistics: {
      totalReviews: 30,
      averageRating: "4.2",
      topProducts: [ /* Produtos mais avaliados */ ],
      trend: { /* Tendência temporal */ }
    }
  }
}
```

## Integração com o Frontend

O agente de IA é integrado ao frontend através do componente `AIAnalysisIntegration`, que processa as avaliações e fornece os dados formatados para o componente visual `AIAnalysis`.

### Componentes:

- **AIAnalysisIntegration**: Integra o agente de IA com o frontend.
- **AIAnalysis**: Exibe visualizações e resumos gerados pelo agente de IA.

### Exemplo de uso:

```jsx
import AIAnalysisIntegration from '@/components/AIAnalysis/AIAnalysisIntegration';

// No componente da página de avaliações
<AIAnalysisIntegration reviews={processedReviews} />
```

## Personalização

### Dicionário de Palavras-Chave

O agente de IA utiliza dicionários de palavras positivas e negativas para análise de sentimento. Você pode personalizar esses dicionários nos arquivos:

- `src/ai/sentimentAnalysis.js`: Dicionários `positiveWords` e `negativeWords`.

### Tópicos

Os tópicos que o agente de IA pode identificar estão definidos no arquivo:

- `src/ai/reviewSummary.js`: Objeto `commonTopics`.

## Testes

O agente de IA inclui um script de teste que verifica o funcionamento de todas as funcionalidades:

```
npm run test:ai
```

Este script executa os seguintes testes:

1. Análise de uma única avaliação (positiva, neutra e negativa).
2. Análise de todas as avaliações.
3. Geração de relatório completo.

## Considerações Finais

O agente de IA implementado neste projeto utiliza uma abordagem baseada em dicionário de palavras-chave para análise de sentimento, o que é uma técnica simples mas eficaz para demonstração. Em um ambiente de produção, seria recomendável utilizar modelos de aprendizado de máquina mais avançados para maior precisão.

Para melhorar a precisão da análise, você pode:

1. Expandir os dicionários de palavras positivas e negativas.
2. Implementar análise de contexto para lidar com negações e sarcasmo.
3. Utilizar modelos de processamento de linguagem natural pré-treinados.
4. Implementar aprendizado contínuo com base no feedback dos usuários.

